# Portfolio Website - Replit.md

## Overview

This is a comprehensive personal portfolio website built with React, Vite, and TailwindCSS. The application showcases Aravinth's professional profile as an Android Developer, Network Security Expert, and Full Stack Engineer. Features ultra-modern glass morphism design, advanced animations, and comprehensive sections highlighting expertise in network security, cryptography, Spring Boot, Kotlin, DSA, and secure application architecture.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Build Tool**: Vite for fast development and optimized production builds
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: React Query (TanStack Query) for server state management
- **Styling**: TailwindCSS with shadcn/ui component library
- **Component System**: Radix UI primitives for accessible, unstyled components

### Backend Architecture
- **Server**: Express.js with TypeScript
- **Architecture Pattern**: RESTful API design
- **Development Setup**: Hot module replacement with Vite middleware in development
- **Storage Interface**: Abstracted storage layer with in-memory implementation
- **Database ORM**: Drizzle ORM configured for PostgreSQL

## Key Components

### UI Components
- **Component Library**: shadcn/ui components built on Radix UI primitives
- **Theme System**: Dark/light mode support with CSS variables
- **Responsive Design**: Mobile-first approach with Tailwind breakpoints
- **Interactive Elements**: Charts (Chart.js), carousels (Swiper.js), typewriter effects

### Portfolio Sections
- **Hero Section**: Animated background, typewriter effect, social links
- **About Section**: Personal information, GitHub contribution graph
- **Skills Section**: Radar chart visualization, technology badges
- **Projects Section**: Filterable gallery with modal previews
- **Certifications**: Auto-sliding carousel of achievements
- **Testimonials**: Client feedback carousel
- **Resume Section**: PDF preview and download functionality
- **Contact Form**: Form handling with toast notifications

### Technical Features
- **PWA Support**: Service worker, manifest file, offline capabilities
- **SEO Optimization**: Meta tags, OpenGraph, Twitter cards
- **Performance**: Code splitting, lazy loading, optimized assets
- **Accessibility**: ARIA labels, keyboard navigation, screen reader support

## Data Flow

### Client-Side Data Management
- **Static Data**: Portfolio content stored in TypeScript data files
- **Dynamic State**: React Query for API calls and caching
- **Local State**: React hooks for component-level state
- **Theme State**: Context provider for dark/light mode persistence

### Server-Side Data Flow
- **API Routes**: Express routes with `/api` prefix
- **Storage Layer**: Abstract interface supporting multiple storage backends
- **Request/Response**: JSON-based API communication
- **Error Handling**: Centralized error middleware with proper HTTP status codes

## External Dependencies

### Core Libraries
- **React Ecosystem**: React 18, React DOM, React Query
- **Build Tools**: Vite, TypeScript, ESBuild for production builds
- **Styling**: TailwindCSS, PostCSS, Autoprefixer
- **UI Components**: Radix UI primitives, Lucide React icons

### Specialized Libraries
- **Charts**: Chart.js for skill visualization
- **Carousels**: Swiper.js for image/content sliders
- **Database**: Drizzle ORM with Neon Database serverless driver
- **Validation**: Zod for schema validation
- **Forms**: React Hook Form with Zod resolvers

### Development Tools
- **Development**: tsx for TypeScript execution
- **Type Checking**: TypeScript compiler
- **Database Migrations**: Drizzle Kit for schema management
- **Error Handling**: Replit-specific development tools

## Deployment Strategy

### Build Process
- **Frontend Build**: Vite builds React app to `dist/public`
- **Backend Build**: ESBuild bundles server code to `dist/index.js`
- **Static Assets**: Public folder served directly by Express in production

### Environment Configuration
- **Development**: Hot reload with Vite middleware integration
- **Production**: Compiled server serving static files
- **Database**: PostgreSQL connection via environment variables
- **Environment Variables**: DATABASE_URL for database connection

### Hosting Considerations
- **Static Hosting**: Frontend can be deployed to CDN
- **Server Hosting**: Node.js environment required for backend
- **Database**: Neon Database (serverless PostgreSQL) for production
- **PWA**: Service worker caching for offline functionality

The application follows modern web development best practices with a focus on performance, accessibility, and user experience. The modular architecture allows for easy maintenance and feature additions while maintaining a clean separation of concerns between frontend presentation and backend data management.

## Recent Changes (January 2025)

### Portfolio Content Updates
- ✓ Updated personal title to "Android Developer | Network Security Expert | Full Stack Engineer"  
- ✓ Enhanced bio to highlight expertise in network security, cryptography, Spring Boot, and DSA
- ✓ Added new technical skills: Network Security, Cryptography, Spring Boot, Kotlin, DSA
- ✓ Expanded technology stack to include Jetpack Compose, Spring Security, Microservices

### New Projects Added
- ✓ Secure Chat App with E2E Encryption (Kotlin, Spring Boot, Cryptography)
- ✓ Secure Banking Microservices Platform (Spring Boot, Spring Security, JWT)
- ✓ Network Security Analyzer (Network Security, Java, DSA, Cryptography)  
- ✓ Modern Android Finance App (Kotlin, Jetpack Compose, Material 3)

### New Certifications Added
- ✓ Network Security Professional (CISSP, 2024)
- ✓ Spring Framework Expert (Pivotal, 2024)
- ✓ Kotlin Android Developer (Google, 2023)
- ✓ Data Structures & Algorithms Expert (LeetCode, 2023)
- ✓ Cryptography & Computer Networks (Stanford Online, 2023)
- ✓ Microservices Architecture (Docker & Kubernetes, 2022)

### Design Enhancements  
- ✓ Ultra-modern glass morphism design with backdrop blur effects
- ✓ Contemporary gradients and neon glow effects
- ✓ Advanced animations: fade-in, slide-in, scale-in, floating elements
- ✓ Enhanced navigation with modern glass card styling
- ✓ Improved project cards with better hover effects
- ✓ Updated filter categories: security, microservices, networking, compose

The portfolio now comprehensively showcases advanced technical expertise in network security, modern Android development with Kotlin, enterprise Spring Boot applications, and secure system architecture.