import { useEffect, useRef } from "react";
import { skills } from "@/data/portfolio-data";

const SkillsSection = () => {
  const chartRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const loadChart = async () => {
      if (!chartRef.current) return;

      // Dynamically import Chart.js
      const { Chart, registerables } = await import('chart.js');
      Chart.register(...registerables);

      const ctx = chartRef.current.getContext('2d');
      if (!ctx) return;

      const isDark = document.documentElement.classList.contains('dark');

      new Chart(ctx, {
        type: 'radar',
        data: {
          labels: skills.technical.map(skill => skill.name),
          datasets: [{
            label: 'Technical Skills',
            data: skills.technical.map(skill => skill.level),
            backgroundColor: 'rgba(139, 92, 246, 0.2)',
            borderColor: 'rgba(139, 92, 246, 1)',
            borderWidth: 2,
            pointBackgroundColor: 'rgba(139, 92, 246, 1)',
            pointBorderColor: '#fff',
            pointHoverBackgroundColor: '#fff',
            pointHoverBorderColor: 'rgba(139, 92, 246, 1)'
          }]
        },
        options: {
          responsive: true,
          maintainAspectRatio: true,
          plugins: {
            legend: {
              display: false
            }
          },
          scales: {
            r: {
              beginAtZero: true,
              max: 100,
              ticks: {
                stepSize: 20,
                color: isDark ? '#9CA3AF' : '#6B7280'
              },
              grid: {
                color: isDark ? '#374151' : '#E5E7EB'
              },
              pointLabels: {
                color: isDark ? '#F9FAFB' : '#1F2937',
                font: {
                  size: 12,
                  weight: 'bold'
                }
              }
            }
          }
        }
      });
    };

    loadChart();
  }, []);

  return (
    <section id="skills" className="py-20 bg-white dark:bg-gray-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="section-title">Technical Skills</h2>
          <p className="section-subtitle">My expertise across different technologies</p>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* Radar Chart */}
          <div className="bg-gray-50 dark:bg-gray-800 p-8 rounded-2xl shadow-lg">
            <canvas ref={chartRef} width="400" height="400"></canvas>
          </div>
          
          {/* Skills List */}
          <div className="space-y-6">
            {skills.technical.map((skill) => (
              <div key={skill.name} className="skill-item">
                <div className="flex justify-between items-center mb-2">
                  <span className="font-semibold text-gray-900 dark:text-white">{skill.name}</span>
                  <span className="text-purple-600 dark:text-purple-400 font-bold">{skill.level}%</span>
                </div>
                <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-3 overflow-hidden">
                  <div 
                    className="h-full bg-gradient-to-r from-purple-500 to-blue-500 rounded-full transition-all duration-1000 ease-out"
                    style={{ width: `${skill.level}%` }}
                  ></div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default SkillsSection;
