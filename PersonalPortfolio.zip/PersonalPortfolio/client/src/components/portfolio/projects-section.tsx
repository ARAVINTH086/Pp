import { useState } from "react";
import { projects } from "@/data/portfolio-data";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogTrigger, DialogTitle } from "@/components/ui/dialog";
import { Github, ExternalLink, Play } from "lucide-react";

const ProjectsSection = () => {
  const [filter, setFilter] = useState("all");
  
  const categories = ["all", "android", "security", "microservices", "networking", "compose", "firebase", "compiler"];
  
  const filteredProjects = projects.filter(project => 
    filter === "all" || project.categories.includes(filter)
  );

  return (
    <section id="projects" className="py-32 bg-gradient-to-b from-black via-purple-950 to-black relative overflow-hidden">
      {/* Background Elements */}
      <div className="absolute inset-0">
        <div className="floating-element top-20 left-10 w-32 h-32 bg-purple-500 animate-float" style={{ animationDelay: '1s' }}></div>
        <div className="floating-element bottom-20 right-10 w-24 h-24 bg-blue-500 animate-float" style={{ animationDelay: '3s' }}></div>
      </div>
      
      <div className="max-w-7xl mx-auto px-6 sm:px-8 lg:px-12 relative z-10">
        <div className="text-center mb-20">
          <h2 className="section-title animate-fade-in">Featured Projects</h2>
          <p className="section-subtitle animate-fade-in">Showcasing my latest work and innovations</p>
        </div>
        
        {/* Project Filter */}
        <div className="flex flex-wrap justify-center gap-4 mb-16">
          {categories.map((category) => (
            <button
              key={category}
              onClick={() => setFilter(category)}
              className={`px-8 py-3 rounded-2xl font-semibold transition-all duration-300 hover:scale-105 ${
                filter === category 
                  ? 'btn-primary' 
                  : 'glass-card text-white hover:bg-white/20'
              }`}
            >
              {category.charAt(0).toUpperCase() + category.slice(1)}
            </button>
          ))}
        </div>
        
        {/* Projects Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10">
          {filteredProjects.map((project, index) => (
            <div key={project.id} className={`project-card animate-fade-in group`} style={{ animationDelay: `${index * 0.2}s` }}>
              <div className="relative overflow-hidden">
                <img 
                  src={project.image}
                  alt={project.title}
                  className="w-full h-56 object-cover transition-all duration-500 group-hover:scale-110 group-hover:brightness-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black via-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-all duration-500">
                  <div className="absolute bottom-6 left-6 right-6">
                    <Dialog>
                      <DialogTrigger asChild>
                        <button className="btn-primary w-full neon-glow">
                          <Play className="w-5 h-5 mr-3" />
                          Watch Demo
                        </button>
                      </DialogTrigger>
                      <DialogContent className="max-w-5xl w-full glass-card border-white/20">
                        <DialogTitle className="text-2xl font-bold gradient-text">{project.title} Demo</DialogTitle>
                        <div className="aspect-video rounded-xl overflow-hidden">
                          <iframe 
                            src={project.demoUrl}
                            className="w-full h-full"
                            allowFullScreen
                            title={`${project.title} Demo`}
                          />
                        </div>
                      </DialogContent>
                    </Dialog>
                  </div>
                </div>
              </div>
              <div className="p-8 space-y-6">
                <h3 className="text-2xl font-bold text-white mb-3 gradient-text">{project.title}</h3>
                <p className="text-gray-300 leading-relaxed">
                  {project.description}
                </p>
                <div className="flex flex-wrap gap-3">
                  {project.tags.map((tag) => (
                    <span key={tag} className="tech-badge">{tag}</span>
                  ))}
                </div>
                <div className="flex gap-4 pt-4">
                  <a 
                    href={project.codeUrl} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="btn-secondary flex-1 text-center"
                  >
                    <Github className="w-5 h-5 mr-3" />
                    Code
                  </a>
                  <a 
                    href={project.liveUrl} 
                    className="btn-primary flex-1 text-center"
                  >
                    <ExternalLink className="w-5 h-5 mr-3" />
                    Demo
                  </a>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ProjectsSection;
