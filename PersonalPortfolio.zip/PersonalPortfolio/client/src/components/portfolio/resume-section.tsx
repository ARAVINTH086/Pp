import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Download, Eye, FileText } from "lucide-react";

const ResumeSection = () => {
  const [showPreview, setShowPreview] = useState(false);

  const togglePreview = () => {
    setShowPreview(!showPreview);
  };

  return (
    <section id="resume" className="py-20 bg-white dark:bg-gray-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="section-title">Resume</h2>
          <p className="section-subtitle">Download or view my latest resume</p>
        </div>
        
        <div className="max-w-4xl mx-auto">
          {/* Resume Preview */}
          <div className="bg-gray-50 dark:bg-gray-800 rounded-2xl shadow-lg p-8 mb-8">
            <div className="aspect-[8.5/11] bg-white dark:bg-gray-700 rounded-lg shadow-inner p-8">
              {showPreview ? (
                <div className="h-full">
                  <iframe 
                    src="/resume.pdf" 
                    className="w-full h-full border rounded-lg"
                    title="Resume Preview"
                  />
                </div>
              ) : (
                <div className="h-full flex flex-col justify-center items-center text-center">
                  <FileText className="w-24 h-24 text-red-500 mb-4" />
                  <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">Resume Preview</h3>
                  <p className="text-gray-600 dark:text-gray-300 mb-6 max-w-md">
                    Complete professional resume with experience, skills, and achievements. 
                    Click "View Online" to preview or download the PDF directly.
                  </p>
                  <div className="bg-gray-100 dark:bg-gray-600 rounded-lg p-4 text-sm text-gray-600 dark:text-gray-400">
                    <p>📄 Professional Experience</p>
                    <p>🎓 Education & Certifications</p>
                    <p>💼 Technical Skills</p>
                    <p>🏆 Projects & Achievements</p>
                  </div>
                </div>
              )}
            </div>
          </div>
          
          {/* Download Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a 
              href="/resume.pdf" 
              download
              className="btn-primary text-center"
            >
              <Download className="w-4 h-4 mr-2" />
              Download Resume (PDF)
            </a>
            <Button 
              onClick={togglePreview}
              className="btn-secondary"
            >
              <Eye className="w-4 h-4 mr-2" />
              {showPreview ? 'Hide Preview' : 'View Online'}
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ResumeSection;
