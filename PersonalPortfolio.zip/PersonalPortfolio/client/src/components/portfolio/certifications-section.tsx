import { useEffect, useRef } from "react";
import { certifications } from "@/data/portfolio-data";
import { ExternalLink } from "lucide-react";

const CertificationsSection = () => {
  const swiperRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const loadSwiper = async () => {
      if (!swiperRef.current) return;

      // Dynamically import Swiper
      const { Swiper } = await import('swiper');
      const { Navigation } = await import('swiper/modules');
      const { Pagination } = await import('swiper/modules');
      const { Autoplay } = await import('swiper/modules');

      new Swiper(swiperRef.current, {
        modules: [Navigation, Pagination, Autoplay],
        slidesPerView: 1,
        spaceBetween: 30,
        autoplay: {
          delay: 4000,
          disableOnInteraction: false,
        },
        pagination: {
          el: '.swiper-pagination',
          clickable: true,
        },
        breakpoints: {
          640: {
            slidesPerView: 2,
          },
          1024: {
            slidesPerView: 3,
          },
        }
      });
    };

    loadSwiper();
  }, []);

  return (
    <section id="certifications" className="py-20 bg-white dark:bg-gray-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="section-title">Certifications & Achievements</h2>
          <p className="section-subtitle">Professional credentials and recognitions</p>
        </div>
        
        {/* Certifications Carousel */}
        <div ref={swiperRef} className="swiper certificationsSwiper">
          <div className="swiper-wrapper">
            {certifications.map((cert) => (
              <div key={cert.id} className="swiper-slide">
                <div className="bg-white dark:bg-gray-700 rounded-xl shadow-lg overflow-hidden mx-4 transition-all duration-300 hover:shadow-xl">
                  <img 
                    src={cert.image}
                    alt={cert.title}
                    className="w-full h-48 object-cover"
                  />
                  <div className="p-6">
                    <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2">{cert.title}</h3>
                    <p className="text-purple-600 dark:text-purple-400 font-semibold mb-2">{cert.organization}</p>
                    <p className="text-gray-600 dark:text-gray-300 mb-4">{cert.description}</p>
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-500 dark:text-gray-400">Issued: {cert.year}</span>
                      <a 
                        href={cert.verifyUrl} 
                        className="text-purple-600 dark:text-purple-400 hover:underline flex items-center gap-1"
                      >
                        <ExternalLink className="w-4 h-4" />
                        View Certificate
                      </a>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
          
          {/* Pagination */}
          <div className="swiper-pagination mt-8"></div>
        </div>
      </div>
    </section>
  );
};

export default CertificationsSection;
