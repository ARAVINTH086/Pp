import { personalInfo, skills } from "@/data/portfolio-data";

const AboutSection = () => {
  return (
    <section id="about" className="py-32 bg-gradient-to-b from-black via-gray-900 to-purple-950 relative overflow-hidden">
      {/* Background Elements */}
      <div className="absolute inset-0">
        <div className="floating-element top-32 right-20 w-40 h-40 bg-blue-500 animate-float" style={{ animationDelay: '2s' }}></div>
        <div className="floating-element bottom-32 left-16 w-28 h-28 bg-purple-500 animate-float" style={{ animationDelay: '4s' }}></div>
      </div>
      
      <div className="max-w-7xl mx-auto px-6 sm:px-8 lg:px-12 relative z-10">
        <div className="text-center mb-20">
          <h2 className="section-title animate-fade-in">About Me</h2>
          <p className="section-subtitle animate-fade-in">Get to know me better</p>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          {/* About Text */}
          <div className="space-y-8 animate-slide-in-left">
            <h3 className="text-3xl sm:text-4xl font-black gradient-text neon-glow">
              Building Tomorrow's Applications Today
            </h3>
            <p className="text-xl text-gray-300 leading-relaxed">
              I'm a passionate software developer with expertise in Android development, system design, and full-stack engineering. 
              My journey in technology spans across mobile applications, real-time communication systems, and compiler design.
            </p>
            <p className="text-xl text-gray-300 leading-relaxed">
              I believe in writing clean, efficient code that solves real-world problems. When I'm not coding, 
              you'll find me exploring new technologies, contributing to open-source projects, or sharing knowledge with the developer community.
            </p>
            
            {/* Quick Stats */}
            <div className="grid grid-cols-2 gap-8 pt-8">
              <div className="text-center glass-card p-8 neon-glow">
                <div className="text-4xl font-black gradient-text mb-2">50+</div>
                <div className="text-gray-300 font-semibold">Projects Completed</div>
              </div>
              <div className="text-center glass-card p-8 neon-glow">
                <div className="text-4xl font-black gradient-text mb-2">3+</div>
                <div className="text-gray-300 font-semibold">Years Experience</div>
              </div>
            </div>
          </div>
          
          {/* Skills Badges */}
          <div className="space-y-8 animate-slide-in-right">
            <h4 className="text-2xl font-bold gradient-text">Technologies I Work With</h4>
            <div className="flex flex-wrap gap-4">
              {skills.technologies.map((tech, index) => (
                <span 
                  key={tech} 
                  className="skill-badge animate-scale-in" 
                  style={{ animationDelay: `${index * 0.1}s` }}
                >
                  {tech}
                </span>
              ))}
            </div>
            
            {/* GitHub Contribution Graph */}
            <div className="mt-12">
              <h4 className="text-2xl font-bold gradient-text mb-6">GitHub Activity</h4>
              <div className="glass-card p-8 neon-glow">
                <img 
                  src="https://ghchart.rshah.org/aravinth-gaming" 
                  alt="Aravinth's GitHub Contribution Graph" 
                  className="w-full rounded-xl"
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;
