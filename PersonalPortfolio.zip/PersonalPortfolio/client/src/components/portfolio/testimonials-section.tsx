import { useEffect, useRef } from "react";
import { testimonials } from "@/data/portfolio-data";
import { Star } from "lucide-react";

const TestimonialsSection = () => {
  const swiperRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const loadSwiper = async () => {
      if (!swiperRef.current) return;

      // Dynamically import Swiper
      const { Swiper } = await import('swiper');
      const { Navigation } = await import('swiper/modules');
      const { Pagination } = await import('swiper/modules');
      const { Autoplay } = await import('swiper/modules');

      new Swiper(swiperRef.current, {
        modules: [Navigation, Pagination, Autoplay],
        slidesPerView: 1,
        spaceBetween: 30,
        autoplay: {
          delay: 5000,
          disableOnInteraction: false,
        },
        pagination: {
          el: '.swiper-pagination',
          clickable: true,
        },
        breakpoints: {
          768: {
            slidesPerView: 2,
          },
        }
      });
    };

    loadSwiper();
  }, []);

  return (
    <section className="py-20 bg-gray-50 dark:bg-gray-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="section-title">What People Say</h2>
          <p className="section-subtitle">Testimonials from colleagues and clients</p>
        </div>
        
        {/* Testimonials Carousel */}
        <div ref={swiperRef} className="swiper testimonialsSwiper">
          <div className="swiper-wrapper">
            {testimonials.map((testimonial) => (
              <div key={testimonial.id} className="swiper-slide">
                <div className="bg-white dark:bg-gray-700 rounded-xl shadow-lg p-8 mx-4 transition-all duration-300 hover:shadow-xl">
                  <div className="flex items-center mb-6">
                    <img 
                      src={testimonial.avatar}
                      alt={testimonial.name}
                      className="w-16 h-16 rounded-full mr-4 object-cover"
                    />
                    <div>
                      <h4 className="font-semibold text-gray-900 dark:text-white">{testimonial.name}</h4>
                      <p className="text-gray-600 dark:text-gray-300">{testimonial.role}</p>
                    </div>
                  </div>
                  <p className="text-lg text-gray-600 dark:text-gray-300 italic leading-relaxed mb-4">
                    "{testimonial.quote}"
                  </p>
                  <div className="flex text-yellow-400">
                    {[...Array(testimonial.rating)].map((_, i) => (
                      <Star key={i} className="w-5 h-5 fill-current" />
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>
          
          {/* Pagination */}
          <div className="swiper-pagination mt-8"></div>
        </div>
      </div>
    </section>
  );
};

export default TestimonialsSection;
