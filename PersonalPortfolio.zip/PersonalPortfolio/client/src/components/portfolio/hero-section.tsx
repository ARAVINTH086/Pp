import { useTypewriter } from "@/hooks/use-typewriter";
import { personalInfo, typewriterRoles } from "@/data/portfolio-data";
import { Button } from "@/components/ui/button";
import { Github, Linkedin, Mail, FileText, ChevronDown } from "lucide-react";

const HeroSection = () => {
  const typewriterText = useTypewriter({
    words: typewriterRoles,
    loop: true,
    delaySpeed: 2000,
    typeSpeed: 100,
    deleteSpeed: 50,
  });

  const scrollToSection = (href: string) => {
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section id="home" className="min-h-screen flex items-center justify-center relative overflow-hidden bg-gradient-to-br from-indigo-900 via-purple-900 to-black">
      {/* Animated Background Elements */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="floating-element -top-40 -right-40 w-96 h-96 bg-purple-500 animate-float animate-glow" style={{ animationDelay: '0s' }}></div>
        <div className="floating-element -bottom-40 -left-40 w-80 h-80 bg-blue-500 animate-float animate-glow" style={{ animationDelay: '2s' }}></div>
        <div className="floating-element top-20 left-1/4 w-64 h-64 bg-pink-500 animate-float animate-glow" style={{ animationDelay: '4s' }}></div>
        
        {/* Additional floating particles */}
        <div className="absolute top-1/4 right-1/3 w-4 h-4 bg-purple-400 rounded-full animate-bounce-slow opacity-60" style={{ animationDelay: '1s' }}></div>
        <div className="absolute bottom-1/3 left-1/5 w-6 h-6 bg-blue-400 rounded-full animate-bounce-slow opacity-40" style={{ animationDelay: '3s' }}></div>
        <div className="absolute top-1/2 right-1/4 w-3 h-3 bg-pink-400 rounded-full animate-bounce-slow opacity-70" style={{ animationDelay: '5s' }}></div>
      </div>
      
      <div className="text-center z-10 px-4 sm:px-6 lg:px-8 max-w-4xl mx-auto">
        {/* Profile Image */}
        <div className="mb-12 animate-scale-in">
          <div className="relative">
            <img 
              src={personalInfo.profileImage}
              alt={`${personalInfo.name} - Professional Profile`}
              className="w-40 h-40 sm:w-48 sm:h-48 rounded-full mx-auto shadow-2xl border-4 border-white/30 object-cover neon-glow"
            />
            <div className="absolute inset-0 rounded-full bg-gradient-to-tr from-purple-400/20 to-blue-400/20 animate-pulse"></div>
          </div>
        </div>
        
        {/* Hero Text */}
        <div className="animate-slide-up space-y-8">
          <h1 className="section-title">
            Hi, I'm <span className="gradient-text neon-glow">{personalInfo.name}</span> 👋
          </h1>
          
          {/* Typewriter Effect */}
          <div className="h-20 sm:h-24 flex items-center justify-center">
            <span className="text-2xl sm:text-3xl lg:text-4xl text-gray-200 font-light">I'm a </span>
            <span className="text-2xl sm:text-3xl lg:text-4xl font-bold gradient-text ml-3 border-r-2 border-purple-400 animate-typewriter min-w-[350px] text-left">
              {typewriterText}
            </span>
          </div>
          
          <p className="section-subtitle mb-12">
            {personalInfo.bio}
          </p>
          
          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row gap-6 justify-center items-center mb-16">
            <button 
              onClick={() => scrollToSection('#projects')}
              className="btn-primary group"
            >
              <FileText className="w-5 h-5 mr-3" />
              View My Work
            </button>
            <button 
              onClick={() => scrollToSection('#contact')}
              className="btn-secondary"
            >
              <Mail className="w-5 h-5 mr-3" />
              Get In Touch
            </button>
          </div>
          
          {/* Social Links */}
          <div className="flex justify-center space-x-8">
            <a 
              href={personalInfo.github} 
              target="_blank" 
              rel="noopener noreferrer" 
              className="social-link neon-glow"
            >
              <Github className="w-7 h-7" />
            </a>
            <a 
              href={personalInfo.linkedin} 
              target="_blank" 
              rel="noopener noreferrer" 
              className="social-link neon-glow"
            >
              <Linkedin className="w-7 h-7" />
            </a>
            <a 
              href={`mailto:${personalInfo.email}`} 
              className="social-link neon-glow"
            >
              <Mail className="w-7 h-7" />
            </a>
            <button 
              onClick={() => scrollToSection('#resume')} 
              className="social-link neon-glow"
            >
              <FileText className="w-7 h-7" />
            </button>
          </div>
        </div>
      </div>
      
      {/* Scroll Down Indicator */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2">
        <button 
          onClick={() => scrollToSection('#about')}
          className="glass-card p-4 text-white hover:text-purple-300 transition-all duration-300 animate-bounce-slow neon-glow"
        >
          <ChevronDown className="w-8 h-8" />
        </button>
      </div>
    </section>
  );
};

export default HeroSection;
