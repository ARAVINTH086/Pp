export const personalInfo = {
  name: "Aravinth",
  title: "Android Developer | Network Security Expert | Full Stack Engineer",
  bio: "Expert in building secure, high-performance applications with strong foundation in network security, cryptography, and modern development frameworks. I specialize in Android (Kotlin & Java), Spring Boot microservices, WebRTC real-time systems, and secure application architecture with deep knowledge of DSA and system design.",
  github: "https://github.com/aravinth-gaming",
  linkedin: "https://linkedin.com/in/aravinth-dev",
  email: "aravinth.dev@example.com",
  whatsapp: "91XXXXXXXXXX",
  profileImage: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&w=200&h=200&fit=crop&crop=face"
};

export const skills = {
  technical: [
    { name: "Android (Kotlin)", level: 98 },
    { name: "Network Security", level: 95 },
    { name: "Cryptography", level: 92 },
    { name: "Spring Boot", level: 90 },
    { name: "Java & Kotlin", level: 95 },
    { name: "DSA", level: 88 },
    { name: "System Design", level: 92 },
    { name: "WebRTC", level: 85 }
  ],
  technologies: [
    "Kotlin", "Java", "Android", "Jetpack Compose", "Spring Boot", "Spring Security", 
    "Microservices", "Network Security", "Cryptography", "Computer Networks",
    "Data Structures & Algorithms", "Firebase", "Room DB", "WebRTC", 
    "System Design", "React", "Node.js", "Git", "Docker", "AWS", "MongoDB"
  ]
};

export const projects = [
  {
    id: 1,
    title: "Secure Chat App with E2E Encryption",
    description: "Advanced chat application with end-to-end encryption, WebRTC video calls, and Spring Boot microservices backend. Features AES-256 encryption, secure key exchange, and comprehensive security protocols.",
    image: "https://images.unsplash.com/photo-1611224923853-80b023f02d71?ixlib=rb-4.0.3&w=600&h=300&fit=crop",
    tags: ["Kotlin", "Jetpack Compose", "Spring Boot", "WebRTC", "Cryptography"],
    categories: ["android", "security", "microservices"],
    demoUrl: "https://www.youtube.com/embed/dQw4w9WgXcQ",
    codeUrl: "https://github.com/aravinth-gaming",
    liveUrl: "#"
  },
  {
    id: 2,
    title: "Smart Bus Tracker",
    description: "Real-time bus tracking system using Google Maps API and Firebase for live location updates, route optimization, and passenger notifications.",
    image: "https://images.unsplash.com/photo-1544620347-c4fd4a3d5957?ixlib=rb-4.0.3&w=600&h=300&fit=crop",
    tags: ["Android", "Google Maps", "Firebase", "GPS"],
    categories: ["android", "maps", "firebase"],
    demoUrl: "https://www.youtube.com/embed/dQw4w9WgXcQ",
    codeUrl: "https://github.com/aravinth-gaming",
    liveUrl: "#"
  },
  {
    id: 3,
    title: "MX Player Clone",
    description: "Advanced video player with custom UI, gesture controls, subtitle support, multiple format compatibility, and smooth playback optimization.",
    image: "https://images.unsplash.com/photo-1489875347897-49f64b51c1f8?ixlib=rb-4.0.3&w=600&h=300&fit=crop",
    tags: ["Android", "ExoPlayer", "Custom UI", "Gestures"],
    categories: ["android"],
    demoUrl: "https://www.youtube.com/embed/dQw4w9WgXcQ",
    codeUrl: "https://github.com/aravinth-gaming",
    liveUrl: "#"
  },
  {
    id: 4,
    title: "Compiler Visualizer",
    description: "Interactive tool for visualizing compilation phases including lexical analysis, syntax parsing, semantic analysis, and code generation with step-by-step breakdown.",
    image: "https://images.unsplash.com/photo-1542831371-29b0f74f9713?ixlib=rb-4.0.3&w=600&h=300&fit=crop",
    tags: ["React", "D3.js", "Compiler Design", "JavaScript"],
    categories: ["compiler"],
    demoUrl: "https://www.youtube.com/embed/dQw4w9WgXcQ",
    codeUrl: "https://github.com/aravinth-gaming",
    liveUrl: "#"
  },
  {
    id: 5,
    title: "E-Commerce Platform",
    description: "Complete e-commerce solution with product catalog, shopping cart, payment integration, order tracking, and admin dashboard for inventory management.",
    image: "https://images.unsplash.com/photo-1563013544-824ae1b704d3?ixlib=rb-4.0.3&w=600&h=300&fit=crop",
    tags: ["Android", "Firebase", "Payment Gateway", "Admin Panel"],
    categories: ["android", "firebase"],
    demoUrl: "https://www.youtube.com/embed/dQw4w9WgXcQ",
    codeUrl: "https://github.com/aravinth-gaming",
    liveUrl: "#"
  },
  {
    id: 6,
    title: "Secure Banking Microservices Platform",
    description: "Enterprise-grade banking application with Spring Boot microservices, Spring Security, JWT authentication, encrypted transactions, and comprehensive audit trails. Features advanced cryptographic protocols and network security measures.",
    image: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?ixlib=rb-4.0.3&w=600&h=300&fit=crop",
    tags: ["Spring Boot", "Spring Security", "Microservices", "Cryptography", "JWT"],
    categories: ["microservices", "security"],
    demoUrl: "https://www.youtube.com/embed/dQw4w9WgXcQ",
    codeUrl: "https://github.com/aravinth-gaming",
    liveUrl: "#"
  },
  {
    id: 7,
    title: "Network Security Analyzer",
    description: "Advanced network security monitoring tool with intrusion detection, packet analysis, vulnerability assessment, and real-time threat monitoring. Built with comprehensive DSA algorithms for efficient network graph traversal and analysis.",
    image: "https://images.unsplash.com/photo-1555949963-aa79dcee981c?ixlib=rb-4.0.3&w=600&h=300&fit=crop",
    tags: ["Network Security", "Java", "DSA", "Cryptography", "Monitoring"],
    categories: ["security", "networking"],
    demoUrl: "https://www.youtube.com/embed/dQw4w9WgXcQ",
    codeUrl: "https://github.com/aravinth-gaming",
    liveUrl: "#"
  },
  {
    id: 8,
    title: "Modern Android Finance App",
    description: "Cutting-edge finance tracking app built with Kotlin and Jetpack Compose. Features biometric authentication, encrypted local storage, real-time cryptocurrency tracking, and beautiful Material 3 design with advanced animations.",
    image: "https://images.unsplash.com/photo-1563013544-824ae1b704d3?ixlib=rb-4.0.3&w=600&h=300&fit=crop",
    tags: ["Kotlin", "Jetpack Compose", "Material 3", "Biometrics", "Room DB"],
    categories: ["android", "compose"],
    demoUrl: "https://www.youtube.com/embed/dQw4w9WgXcQ",
    codeUrl: "https://github.com/aravinth-gaming",
    liveUrl: "#"
  }
];

export const certifications = [
  {
    id: 1,
    title: "Network Security Professional",
    organization: "CISSP",
    year: "2024",
    description: "Comprehensive certification in network security, cryptography, risk management, and security architecture design.",
    image: "https://images.unsplash.com/photo-1522252234503-e356532cafd5?ixlib=rb-4.0.3&w=300&h=200&fit=crop",
    verifyUrl: "#"
  },
  {
    id: 2,
    title: "Spring Framework Expert",
    organization: "Pivotal",
    year: "2024",
    description: "Advanced Spring Boot and Spring Security certification covering microservices architecture, security implementation, and enterprise integration patterns.",
    image: "https://images.unsplash.com/photo-1560472354-b33ff0c44a43?ixlib=rb-4.0.3&w=300&h=200&fit=crop",
    verifyUrl: "#"
  },
  {
    id: 3,
    title: "Kotlin Android Developer",
    organization: "Google",
    year: "2023",
    description: "Advanced Android development with Kotlin and Jetpack Compose, covering modern UI design patterns and performance optimization.",
    image: "https://images.unsplash.com/photo-1522252234503-e356532cafd5?ixlib=rb-4.0.3&w=300&h=200&fit=crop",
    verifyUrl: "#"
  },
  {
    id: 2,
    title: "Firebase Expert",
    organization: "Firebase Academy",
    year: "2023",
    description: "Comprehensive Firebase certification covering real-time databases, authentication, cloud functions, and deployment strategies.",
    image: "https://images.unsplash.com/photo-1560472354-b33ff0c44a43?ixlib=rb-4.0.3&w=300&h=200&fit=crop",
    verifyUrl: "#"
  },
  {
    id: 3,
    title: "System Design Mastery",
    organization: "Udemy",
    year: "2022",
    description: "In-depth system design course covering scalability, microservices, distributed systems, and architectural patterns.",
    image: "https://images.unsplash.com/photo-1558494949-ef010cbdcc31?ixlib=rb-4.0.3&w=300&h=200&fit=crop",
    verifyUrl: "#"
  },
  {
    id: 4,
    title: "Data Structures & Algorithms Expert",
    organization: "LeetCode",
    year: "2023",
    description: "Advanced DSA certification demonstrating proficiency in complex algorithmic problem solving, optimization techniques, and efficient data structure implementation.",
    image: "https://images.unsplash.com/photo-1515879218367-8466d910aaa4?ixlib=rb-4.0.3&w=300&h=200&fit=crop",
    verifyUrl: "#"
  },
  {
    id: 5,
    title: "Cryptography & Computer Networks",
    organization: "Stanford Online",
    year: "2023",
    description: "Comprehensive course covering cryptographic protocols, network security, secure communication, and distributed systems architecture.",
    image: "https://images.unsplash.com/photo-1558494949-ef010cbdcc31?ixlib=rb-4.0.3&w=300&h=200&fit=crop",
    verifyUrl: "#"
  },
  {
    id: 6,
    title: "Microservices Architecture",
    organization: "Docker & Kubernetes",
    year: "2022",
    description: "Advanced certification in containerized microservices, orchestration, service mesh architecture, and cloud-native development patterns.",
    image: "https://images.unsplash.com/photo-1515879218367-8466d910aaa4?ixlib=rb-4.0.3&w=300&h=200&fit=crop",
    verifyUrl: "#"
  }
];

export const testimonials = [
  {
    id: 1,
    name: "Sarah Johnson",
    role: "Security Architect at CyberSecure Inc",
    quote: "Aravinth delivered an exceptional secure banking platform with Spring Boot microservices and advanced cryptography. His expertise in network security and encryption protocols exceeded our expectations for enterprise-grade security.",
    avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&w=80&h=80&fit=crop&crop=face",
    rating: 5
  },
  {
    id: 2,
    name: "Michael Chen",
    role: "Senior Developer at TechCorp",
    quote: "His compiler knowledge and system design skills blew us away. Aravinth consistently delivers high-quality code and brings innovative solutions to complex problems.",
    avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&w=80&h=80&fit=crop&crop=face",
    rating: 5
  },
  {
    id: 3,
    name: "Emily Rodriguez",
    role: "Project Manager at StartupHub",
    quote: "Working with Aravinth was a game-changer for our mobile app project. His expertise in Android development and Firebase integration helped us launch on time with exceptional quality.",
    avatar: "https://images.unsplash.com/photo-1494790108755-2616b332c93b?ixlib=rb-4.0.3&w=80&h=80&fit=crop&crop=face",
    rating: 5
  }
];

export const typewriterRoles = [
  "Android Developer",
  "System Designer", 
  "Compiler Enthusiast",
  "Full Stack Engineer"
];
