import { useState, useEffect } from 'react';

interface UseTypewriterProps {
  words: string[];
  loop?: boolean;
  delaySpeed?: number;
  typeSpeed?: number;
  deleteSpeed?: number;
}

export function useTypewriter({
  words,
  loop = true,
  delaySpeed = 2000,
  typeSpeed = 100,
  deleteSpeed = 50,
}: UseTypewriterProps) {
  const [currentWord, setCurrentWord] = useState('');
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isDeleting, setIsDeleting] = useState(false);

  useEffect(() => {
    const timeout = setTimeout(() => {
      const current = words[currentIndex];
      
      if (isDeleting) {
        setCurrentWord(prev => prev.substring(0, prev.length - 1));
      } else {
        setCurrentWord(prev => current.substring(0, prev.length + 1));
      }

      if (!isDeleting && currentWord === current) {
        setTimeout(() => setIsDeleting(true), delaySpeed);
      } else if (isDeleting && currentWord === '') {
        setIsDeleting(false);
        setCurrentIndex(prev => loop ? (prev + 1) % words.length : Math.min(prev + 1, words.length - 1));
      }
    }, isDeleting ? deleteSpeed : typeSpeed);

    return () => clearTimeout(timeout);
  }, [currentWord, currentIndex, isDeleting, words, loop, delaySpeed, typeSpeed, deleteSpeed]);

  return currentWord;
}
