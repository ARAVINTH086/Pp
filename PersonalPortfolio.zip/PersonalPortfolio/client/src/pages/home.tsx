import Navigation from "@/components/portfolio/navigation";
import HeroSection from "@/components/portfolio/hero-section";
import AboutSection from "@/components/portfolio/about-section";
import SkillsSection from "@/components/portfolio/skills-section";
import ProjectsSection from "@/components/portfolio/projects-section";
import CertificationsSection from "@/components/portfolio/certifications-section";
import TestimonialsSection from "@/components/portfolio/testimonials-section";
import ResumeSection from "@/components/portfolio/resume-section";
import ContactSection from "@/components/portfolio/contact-section";
import Footer from "@/components/portfolio/footer";
import FloatingWhatsApp from "@/components/portfolio/floating-whatsapp";

export default function Home() {
  return (
    <main className="min-h-screen">
      <Navigation />
      <HeroSection />
      <AboutSection />
      <SkillsSection />
      <ProjectsSection />
      <CertificationsSection />
      <TestimonialsSection />
      <ResumeSection />
      <ContactSection />
      <Footer />
      <FloatingWhatsApp />
    </main>
  );
}
