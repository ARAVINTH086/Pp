import { useState, useEffect, useRef } from 'react';
import { WebRTCService } from '@/lib/webrtc';

export interface Participant {
  id: string;
  name: string;
  stream?: MediaStream;
  isMuted: boolean;
  isVideoEnabled: boolean;
}

export function useWebRTC(roomId: string, userId: string, userName: string) {
  const [localStream, setLocalStream] = useState<MediaStream | null>(null);
  const [participants, setParticipants] = useState<Map<string, Participant>>(new Map());
  const [isConnected, setIsConnected] = useState(false);
  const [isConnecting, setIsConnecting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isMuted, setIsMuted] = useState(false);
  const [isVideoEnabled, setIsVideoEnabled] = useState(true);
  
  const webrtcService = useRef<WebRTCService | null>(null);

  useEffect(() => {
    if (!roomId || !userId) return;

    initializeWebRTC();

    return () => {
      webrtcService.current?.disconnect();
    };
  }, [roomId, userId]);

  const initializeWebRTC = async () => {
    try {
      setIsConnecting(true);
      setError(null);

      webrtcService.current = new WebRTCService(roomId, userId);
      
      // Set up callbacks
      webrtcService.current.onRemoteStream((stream, remoteUserId) => {
        setParticipants(prev => new Map(prev.set(remoteUserId, {
          id: remoteUserId,
          name: `User ${remoteUserId}`, // This should come from participant data
          stream,
          isMuted: false,
          isVideoEnabled: true,
        })));
      });

      webrtcService.current.onParticipantLeft((remoteUserId) => {
        setParticipants(prev => {
          const updated = new Map(prev);
          updated.delete(remoteUserId);
          return updated;
        });
      });

      // Initialize local stream
      const stream = await webrtcService.current.initializeLocalStream();
      setLocalStream(stream);

      // Add self as participant
      setParticipants(prev => new Map(prev.set(userId, {
        id: userId,
        name: userName,
        stream,
        isMuted: false,
        isVideoEnabled: true,
      })));

      // Create offer to start connection process
      await webrtcService.current.createOffer();

      setIsConnected(true);
      setIsConnecting(false);
    } catch (err) {
      console.error('Failed to initialize WebRTC:', err);
      setError(err instanceof Error ? err.message : 'Failed to connect');
      setIsConnecting(false);
    }
  };

  const toggleMicrophone = () => {
    if (webrtcService.current) {
      const newMutedState = !isMuted;
      webrtcService.current.toggleAudio(!newMutedState);
      setIsMuted(newMutedState);
      
      // Update local participant
      setParticipants(prev => {
        const updated = new Map(prev);
        const localParticipant = updated.get(userId);
        if (localParticipant) {
          updated.set(userId, { ...localParticipant, isMuted: newMutedState });
        }
        return updated;
      });
    }
  };

  const toggleCamera = () => {
    if (webrtcService.current) {
      const newVideoState = !isVideoEnabled;
      webrtcService.current.toggleVideo(newVideoState);
      setIsVideoEnabled(newVideoState);
      
      // Update local participant
      setParticipants(prev => {
        const updated = new Map(prev);
        const localParticipant = updated.get(userId);
        if (localParticipant) {
          updated.set(userId, { ...localParticipant, isVideoEnabled: newVideoState });
        }
        return updated;
      });
    }
  };

  const endCall = () => {
    webrtcService.current?.disconnect();
    setIsConnected(false);
    setLocalStream(null);
    setParticipants(new Map());
  };

  return {
    localStream,
    participants: Array.from(participants.values()),
    isConnected,
    isConnecting,
    error,
    isMuted,
    isVideoEnabled,
    toggleMicrophone,
    toggleCamera,
    endCall,
    retryConnection: initializeWebRTC,
  };
}
