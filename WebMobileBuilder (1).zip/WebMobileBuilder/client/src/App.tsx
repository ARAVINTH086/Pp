import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import Lobby from "@/pages/lobby";
import Call from "@/pages/call";
import AdvancedCall from "@/pages/advanced-call";

// Header Component
function Header() {
  return (
    <header className="bg-gray-800 border-b border-gray-700 px-4 py-3">
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <div className="text-2xl font-bold text-white">
            <i className="fas fa-video text-blue-500 mr-2"></i>
            VideoConnect
          </div>
        </div>
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-2 text-sm text-white">
            <div className="w-2 h-2 bg-green-500 rounded-full"></div>
            <span>Online</span>
          </div>
          <div className="relative">
            <div className="w-8 h-8 bg-gray-600 rounded-full border-2 border-gray-500 flex items-center justify-center">
              <span className="text-sm text-white">U</span>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}

function Router() {
  return (
    <Switch>
      <Route path="/" component={Lobby} />
      <Route path="/call/:roomId" component={Call} />
      <Route path="/advanced-call/:roomId" component={AdvancedCall} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <div className="min-h-screen bg-gray-900">
          <Header />
          <Router />
        </div>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
