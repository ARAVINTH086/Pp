import { useState } from 'react';
import { useLocation } from 'wouter';
import { useMutation, useQuery } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Slider } from '@/components/ui/slider';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useToast } from '@/hooks/use-toast';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Video, 
  Plus, 
  Users, 
  Clock, 
  ChevronRight,
  Settings,
  Shield,
  Mic,
  Camera,
  Monitor,
  MessageSquare,
  Brain,
  Palette,
  Globe,
  Lock,
  Eye,
  Zap,
  Star,
  Calendar,
  Share2,
  Copy,
  QrCode
} from 'lucide-react';
import type { CallHistory, Room } from '@shared/schema';

export default function AdvancedLobby() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  
  const [activeTab, setActiveTab] = useState('join');
  const [joinForm, setJoinForm] = useState({
    roomId: '',
    userName: '',
  });
  
  const [createForm, setCreateForm] = useState({
    roomName: '',
    userName: '',
    roomType: 'video' as 'video' | 'audio' | 'screen-share',
    maxParticipants: 10,
    isLocked: false,
    password: '',
    waitingRoom: false,
    backgroundBlur: true,
    chatEnabled: true,
    screenShareEnabled: true,
    whiteboardEnabled: true,
  });

  const [showAdvancedSettings, setShowAdvancedSettings] = useState(false);
  const [generatedRoomCode, setGeneratedRoomCode] = useState<string | null>(null);

  // Generate a simple user ID for demo purposes
  const userId = `user_${Date.now()}`;

  // Fetch call history
  const { data: callHistory = [] } = useQuery<CallHistory[]>({
    queryKey: ['/api/call-history', userId],
  });

  const generateRoomCode = () => {
    const code = Math.random().toString(36).substr(2, 8).toUpperCase();
    setGeneratedRoomCode(code);
    setJoinForm(prev => ({ ...prev, roomId: code }));
  };

  const joinRoomMutation = useMutation({
    mutationFn: async (data: { roomId: string; userName: string; userId: string }) => {
      const response = await apiRequest('POST', `/api/rooms/${data.roomId}/join`, {
        userName: data.userName,
        userId: data.userId,
      });
      return response.json();
    },
    onSuccess: (data) => {
      toast({
        title: 'Joined room successfully',
        description: `Connected to ${data.room.name}`,
      });
      setLocation(`/call/${data.room.id}?userId=${userId}&userName=${encodeURIComponent(joinForm.userName)}`);
    },
    onError: (error) => {
      toast({
        title: 'Failed to join room',
        description: error.message,
        variant: 'destructive',
      });
    },
  });

  const createRoomMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await apiRequest('POST', '/api/rooms', data);
      return response.json();
    },
    onSuccess: (data) => {
      toast({
        title: 'Room created successfully',
        description: `Created ${data.name} - Room ID: ${data.id}`,
      });
      setLocation(`/call/${data.id}?userId=${userId}&userName=${encodeURIComponent(createForm.userName)}`);
    },
    onError: (error) => {
      toast({
        title: 'Failed to create room',
        description: error.message,
        variant: 'destructive',
      });
    },
  });

  const handleJoinRoom = (e: React.FormEvent) => {
    e.preventDefault();
    if (!joinForm.roomId.trim() || !joinForm.userName.trim()) {
      toast({
        title: 'Missing information',
        description: 'Please enter both room ID and your name',
        variant: 'destructive',
      });
      return;
    }
    
    joinRoomMutation.mutate({
      roomId: joinForm.roomId.trim(),
      userName: joinForm.userName.trim(),
      userId,
    });
  };

  const handleCreateRoom = (e: React.FormEvent) => {
    e.preventDefault();
    if (!createForm.roomName.trim() || !createForm.userName.trim()) {
      toast({
        title: 'Missing information',
        description: 'Please enter both room name and your name',
        variant: 'destructive',
      });
      return;
    }

    const roomData = {
      name: createForm.roomName.trim(),
      createdBy: userId,
      userId,
      userName: createForm.userName.trim(),
      ...createForm,
    };

    createRoomMutation.mutate(roomData);
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast({
      title: 'Copied to clipboard',
      description: 'Room code copied successfully',
    });
  };

  const handleRejoinCall = (roomId: string, roomName: string) => {
    const userName = 'Returning User';
    setLocation(`/call/${roomId}?userId=${userId}&userName=${encodeURIComponent(userName)}`);
  };

  const formatDuration = (seconds: number | null) => {
    if (!seconds) return 'Unknown duration';
    const mins = Math.floor(seconds / 60);
    return `${mins} min`;
  };

  const formatDate = (date: Date) => {
    const now = new Date();
    const isToday = date.toDateString() === now.toDateString();
    const isYesterday = new Date(now.getTime() - 24 * 60 * 60 * 1000).toDateString() === date.toDateString();
    
    if (isToday) {
      return `Today, ${date.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit', hour12: true })}`;
    } else if (isYesterday) {
      return `Yesterday, ${date.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit', hour12: true })}`;
    } else {
      return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit', hour12: true });
    }
  };

  const roomTypeIcons = {
    video: Video,
    audio: Mic,
    'screen-share': Monitor,
  };

  const RoomTypeIcon = roomTypeIcons[createForm.roomType];

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-blue-900/20 to-purple-900/20 py-8">
      <div className="max-w-6xl mx-auto px-4">
        
        {/* Header with Glass Effect */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-12"
        >
          <div className="bg-white/5 backdrop-blur-xl rounded-3xl border border-white/10 p-8 mb-8">
            <h1 className="text-5xl font-bold mb-4 bg-gradient-to-r from-blue-400 via-purple-400 to-pink-400 bg-clip-text text-transparent">
              VideoConnect Pro
            </h1>
            <p className="text-xl text-gray-300">Next-generation video collaboration platform</p>
            <div className="flex items-center justify-center space-x-6 mt-6">
              <div className="flex items-center space-x-2">
                <Brain className="h-5 w-5 text-purple-400" />
                <span className="text-sm text-gray-300">AI-Powered</span>
              </div>
              <div className="flex items-center space-x-2">
                <Shield className="h-5 w-5 text-green-400" />
                <span className="text-sm text-gray-300">Secure</span>
              </div>
              <div className="flex items-center space-x-2">
                <Zap className="h-5 w-5 text-yellow-400" />
                <span className="text-sm text-gray-300">Real-time</span>
              </div>
            </div>
          </div>
        </motion.div>

        {/* Main Content */}
        <div className="grid lg:grid-cols-3 gap-8">
          
          {/* Left Column - Join/Create */}
          <div className="lg:col-span-2">
            <Card className="bg-white/5 backdrop-blur-xl border-white/10">
              <CardHeader>
                <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
                  <TabsList className="grid w-full grid-cols-2 bg-gray-800/50">
                    <TabsTrigger value="join" className="data-[state=active]:bg-blue-500">
                      <Video className="mr-2 h-4 w-4" />
                      Join Room
                    </TabsTrigger>
                    <TabsTrigger value="create" className="data-[state=active]:bg-green-500">
                      <Plus className="mr-2 h-4 w-4" />
                      Create Room
                    </TabsTrigger>
                  </TabsList>
                </Tabs>
              </CardHeader>

              <CardContent>
                <AnimatePresence mode="wait">
                  {activeTab === 'join' && (
                    <motion.div
                      key="join"
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: 20 }}
                      transition={{ duration: 0.2 }}
                    >
                      <form onSubmit={handleJoinRoom} className="space-y-6">
                        <div className="space-y-4">
                          <div>
                            <Label htmlFor="joinRoomId" className="text-white text-lg font-medium">Room Code</Label>
                            <div className="flex space-x-2">
                              <Input
                                id="joinRoomId"
                                type="text"
                                placeholder="Enter 8-digit room code..."
                                value={joinForm.roomId}
                                onChange={(e) => setJoinForm(prev => ({ ...prev, roomId: e.target.value.toUpperCase() }))}
                                className="bg-gray-800/50 border-gray-600 text-white placeholder-gray-400 text-lg font-mono"
                                maxLength={8}
                              />
                              <Button
                                type="button"
                                variant="outline"
                                onClick={generateRoomCode}
                                className="border-gray-600 text-white hover:bg-gray-700"
                              >
                                Generate
                              </Button>
                            </div>
                          </div>
                          
                          <div>
                            <Label htmlFor="joinUserName" className="text-white text-lg font-medium">Your Name</Label>
                            <Input
                              id="joinUserName"
                              type="text"
                              placeholder="Enter your display name..."
                              value={joinForm.userName}
                              onChange={(e) => setJoinForm(prev => ({ ...prev, userName: e.target.value }))}
                              className="bg-gray-800/50 border-gray-600 text-white placeholder-gray-400 text-lg"
                            />
                          </div>
                        </div>
                        
                        <Button 
                          type="submit" 
                          className="w-full bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 text-white font-semibold text-lg py-6"
                          disabled={joinRoomMutation.isPending}
                        >
                          <Video className="mr-2 h-5 w-5" />
                          {joinRoomMutation.isPending ? 'Joining...' : 'Join Room'}
                        </Button>
                      </form>
                    </motion.div>
                  )}

                  {activeTab === 'create' && (
                    <motion.div
                      key="create"
                      initial={{ opacity: 0, x: 20 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: -20 }}
                      transition={{ duration: 0.2 }}
                    >
                      <form onSubmit={handleCreateRoom} className="space-y-6">
                        <div className="space-y-4">
                          <div>
                            <Label htmlFor="createRoomName" className="text-white text-lg font-medium">Room Name</Label>
                            <Input
                              id="createRoomName"
                              type="text"
                              placeholder="Enter room name..."
                              value={createForm.roomName}
                              onChange={(e) => setCreateForm(prev => ({ ...prev, roomName: e.target.value }))}
                              className="bg-gray-800/50 border-gray-600 text-white placeholder-gray-400 text-lg"
                            />
                          </div>
                          
                          <div>
                            <Label htmlFor="createUserName" className="text-white text-lg font-medium">Your Name</Label>
                            <Input
                              id="createUserName"
                              type="text"
                              placeholder="Enter your display name..."
                              value={createForm.userName}
                              onChange={(e) => setCreateForm(prev => ({ ...prev, userName: e.target.value }))}
                              className="bg-gray-800/50 border-gray-600 text-white placeholder-gray-400 text-lg"
                            />
                          </div>

                          {/* Room Type Selection */}
                          <div>
                            <Label className="text-white text-lg font-medium mb-3 block">Meeting Type</Label>
                            <div className="grid grid-cols-3 gap-3">
                              {(['video', 'audio', 'screen-share'] as const).map((type) => {
                                const Icon = roomTypeIcons[type];
                                return (
                                  <button
                                    key={type}
                                    type="button"
                                    onClick={() => setCreateForm(prev => ({ ...prev, roomType: type }))}
                                    className={`p-4 rounded-lg border-2 transition-all ${
                                      createForm.roomType === type
                                        ? 'border-blue-500 bg-blue-500/20'
                                        : 'border-gray-600 bg-gray-800/50 hover:border-gray-500'
                                    }`}
                                  >
                                    <Icon className="h-6 w-6 mx-auto mb-2 text-white" />
                                    <span className="text-sm text-white capitalize">
                                      {type.replace('-', ' ')}
                                    </span>
                                  </button>
                                );
                              })}
                            </div>
                          </div>

                          {/* Max Participants */}
                          <div>
                            <Label className="text-white text-lg font-medium">Max Participants: {createForm.maxParticipants}</Label>
                            <Slider
                              value={[createForm.maxParticipants]}
                              onValueChange={([value]) => setCreateForm(prev => ({ ...prev, maxParticipants: value }))}
                              max={50}
                              min={2}
                              step={1}
                              className="mt-2"
                            />
                          </div>

                          {/* Advanced Settings Toggle */}
                          <Button
                            type="button"
                            variant="ghost"
                            onClick={() => setShowAdvancedSettings(!showAdvancedSettings)}
                            className="w-full text-blue-400 hover:text-blue-300"
                          >
                            <Settings className="mr-2 h-4 w-4" />
                            {showAdvancedSettings ? 'Hide' : 'Show'} Advanced Settings
                          </Button>

                          {/* Advanced Settings */}
                          <AnimatePresence>
                            {showAdvancedSettings && (
                              <motion.div
                                initial={{ opacity: 0, height: 0 }}
                                animate={{ opacity: 1, height: 'auto' }}
                                exit={{ opacity: 0, height: 0 }}
                                className="space-y-4 p-4 bg-gray-800/30 rounded-lg border border-gray-700"
                              >
                                <div className="grid grid-cols-2 gap-4">
                                  <div className="flex items-center justify-between">
                                    <Label className="text-white flex items-center space-x-2">
                                      <Lock className="h-4 w-4" />
                                      <span>Private Room</span>
                                    </Label>
                                    <Switch
                                      checked={createForm.isLocked}
                                      onCheckedChange={(checked) => setCreateForm(prev => ({ ...prev, isLocked: checked }))}
                                    />
                                  </div>

                                  <div className="flex items-center justify-between">
                                    <Label className="text-white flex items-center space-x-2">
                                      <Eye className="h-4 w-4" />
                                      <span>Waiting Room</span>
                                    </Label>
                                    <Switch
                                      checked={createForm.waitingRoom}
                                      onCheckedChange={(checked) => setCreateForm(prev => ({ ...prev, waitingRoom: checked }))}
                                    />
                                  </div>

                                  <div className="flex items-center justify-between">
                                    <Label className="text-white flex items-center space-x-2">
                                      <Palette className="h-4 w-4" />
                                      <span>Background Blur</span>
                                    </Label>
                                    <Switch
                                      checked={createForm.backgroundBlur}
                                      onCheckedChange={(checked) => setCreateForm(prev => ({ ...prev, backgroundBlur: checked }))}
                                    />
                                  </div>

                                  <div className="flex items-center justify-between">
                                    <Label className="text-white flex items-center space-x-2">
                                      <MessageSquare className="h-4 w-4" />
                                      <span>Chat</span>
                                    </Label>
                                    <Switch
                                      checked={createForm.chatEnabled}
                                      onCheckedChange={(checked) => setCreateForm(prev => ({ ...prev, chatEnabled: checked }))}
                                    />
                                  </div>

                                  <div className="flex items-center justify-between">
                                    <Label className="text-white flex items-center space-x-2">
                                      <Monitor className="h-4 w-4" />
                                      <span>Screen Share</span>
                                    </Label>
                                    <Switch
                                      checked={createForm.screenShareEnabled}
                                      onCheckedChange={(checked) => setCreateForm(prev => ({ ...prev, screenShareEnabled: checked }))}
                                    />
                                  </div>

                                  <div className="flex items-center justify-between">
                                    <Label className="text-white flex items-center space-x-2">
                                      <Brain className="h-4 w-4" />
                                      <span>Whiteboard</span>
                                    </Label>
                                    <Switch
                                      checked={createForm.whiteboardEnabled}
                                      onCheckedChange={(checked) => setCreateForm(prev => ({ ...prev, whiteboardEnabled: checked }))}
                                    />
                                  </div>
                                </div>

                                {createForm.isLocked && (
                                  <div>
                                    <Label className="text-white">Room Password</Label>
                                    <Input
                                      type="password"
                                      placeholder="Enter room password..."
                                      value={createForm.password}
                                      onChange={(e) => setCreateForm(prev => ({ ...prev, password: e.target.value }))}
                                      className="bg-gray-700 border-gray-600 text-white placeholder-gray-400"
                                    />
                                  </div>
                                )}
                              </motion.div>
                            )}
                          </AnimatePresence>
                        </div>
                        
                        <Button 
                          type="submit" 
                          className="w-full bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white font-semibold text-lg py-6"
                          disabled={createRoomMutation.isPending}
                        >
                          <RoomTypeIcon className="mr-2 h-5 w-5" />
                          {createRoomMutation.isPending ? 'Creating...' : 'Create Room'}
                        </Button>
                      </form>
                    </motion.div>
                  )}
                </AnimatePresence>
              </CardContent>
            </Card>
          </div>

          {/* Right Column - Call History */}
          <div>
            <Card className="bg-white/5 backdrop-blur-xl border-white/10">
              <CardHeader>
                <CardTitle className="text-xl font-semibold flex items-center text-white">
                  <Clock className="text-blue-500 mr-3" />
                  Recent Calls
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {callHistory.length === 0 ? (
                    <div className="text-center py-8 text-gray-400">
                      <Video className="mx-auto mb-4 h-12 w-12 text-gray-600" />
                      <p>No recent calls</p>
                      <p className="text-sm">Your call history will appear here</p>
                    </div>
                  ) : (
                    callHistory.slice(0, 5).map((call) => (
                      <motion.div
                        key={call.id}
                        whileHover={{ scale: 1.02 }}
                        whileTap={{ scale: 0.98 }}
                        className="p-4 bg-gray-800/30 rounded-lg hover:bg-gray-700/30 transition-all cursor-pointer border border-gray-700/50"
                        onClick={() => handleRejoinCall(call.roomId, call.roomName)}
                      >
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-3">
                            <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-purple-500 rounded-full flex items-center justify-center">
                              <Video className="text-white h-5 w-5" />
                            </div>
                            <div>
                              <p className="font-medium text-white">{call.roomName}</p>
                              <p className="text-sm text-gray-400">
                                {formatDate(new Date(call.startedAt))} • {formatDuration(call.duration)}
                              </p>
                            </div>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Badge variant="secondary" className="text-xs">
                              <Users className="h-3 w-3 mr-1" />
                              {call.participantCount}
                            </Badge>
                            <ChevronRight className="h-4 w-4 text-gray-400" />
                          </div>
                        </div>
                      </motion.div>
                    ))
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Quick Actions */}
            <Card className="bg-white/5 backdrop-blur-xl border-white/10 mt-6">
              <CardHeader>
                <CardTitle className="text-lg font-semibold text-white">Quick Actions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Button variant="ghost" className="w-full justify-start text-white hover:bg-gray-700/30">
                  <Calendar className="mr-3 h-4 w-4" />
                  Schedule Meeting
                </Button>
                <Button variant="ghost" className="w-full justify-start text-white hover:bg-gray-700/30">
                  <Share2 className="mr-3 h-4 w-4" />
                  Share Room Link
                </Button>
                <Button variant="ghost" className="w-full justify-start text-white hover:bg-gray-700/30">
                  <QrCode className="mr-3 h-4 w-4" />
                  Generate QR Code
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}