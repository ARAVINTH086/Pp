import { useState, useRef, useEffect, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Pen, 
  Square, 
  Circle, 
  ArrowRight, 
  Type, 
  Palette,
  Eraser,
  Undo,
  Redo,
  Download,
  X,
  MousePointer,
  Highlighter,
  Zap
} from 'lucide-react';

interface AnnotationTool {
  id: string;
  name: string;
  icon: React.ReactNode;
  cursor: string;
}

interface DrawingData {
  tool: string;
  color: string;
  size: number;
  points: { x: number; y: number }[];
  timestamp: number;
}

interface ScreenAnnotationProps {
  isActive: boolean;
  onClose: () => void;
  screenStream?: MediaStream;
}

export default function ScreenAnnotation({
  isActive,
  onClose,
  screenStream
}: ScreenAnnotationProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const [selectedTool, setSelectedTool] = useState('pen');
  const [selectedColor, setSelectedColor] = useState('#ff3b30');
  const [brushSize, setBrushSize] = useState(3);
  const [drawings, setDrawings] = useState<DrawingData[]>([]);
  const [currentPath, setCurrentPath] = useState<{ x: number; y: number }[]>([]);
  const [undoStack, setUndoStack] = useState<DrawingData[][]>([]);
  const [redoStack, setRedoStack] = useState<DrawingData[][]>([]);

  const tools: AnnotationTool[] = [
    { id: 'pen', name: 'Pen', icon: <Pen className="h-4 w-4" />, cursor: 'crosshair' },
    { id: 'highlighter', name: 'Highlighter', icon: <Highlighter className="h-4 w-4" />, cursor: 'crosshair' },
    { id: 'rectangle', name: 'Rectangle', icon: <Square className="h-4 w-4" />, cursor: 'crosshair' },
    { id: 'circle', name: 'Circle', icon: <Circle className="h-4 w-4" />, cursor: 'crosshair' },
    { id: 'arrow', name: 'Arrow', icon: <ArrowRight className="h-4 w-4" />, cursor: 'crosshair' },
    { id: 'text', name: 'Text', icon: <Type className="h-4 w-4" />, cursor: 'text' },
    { id: 'laser', name: 'Laser Pointer', icon: <Zap className="h-4 w-4" />, cursor: 'pointer' },
    { id: 'eraser', name: 'Eraser', icon: <Eraser className="h-4 w-4" />, cursor: 'grab' },
  ];

  const colors = [
    '#ff3b30', '#ff9500', '#ffcc02', '#34c759', '#007aff',
    '#5856d6', '#af52de', '#ff2d92', '#ffffff', '#000000'
  ];

  useEffect(() => {
    if (screenStream && videoRef.current) {
      videoRef.current.srcObject = screenStream;
    }
  }, [screenStream]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const context = canvas.getContext('2d');
    if (!context) return;

    // Clear canvas
    context.clearRect(0, 0, canvas.width, canvas.height);

    // Draw all existing drawings
    drawings.forEach(drawing => {
      drawPath(context, drawing);
    });

    // Draw current path being drawn
    if (currentPath.length > 0 && isDrawing) {
      const tempDrawing: DrawingData = {
        tool: selectedTool,
        color: selectedColor,
        size: brushSize,
        points: currentPath,
        timestamp: Date.now()
      };
      drawPath(context, tempDrawing);
    }
  }, [drawings, currentPath, isDrawing, selectedTool, selectedColor, brushSize]);

  const drawPath = (context: CanvasRenderingContext2D, drawing: DrawingData) => {
    if (drawing.points.length < 2) return;

    context.save();
    context.strokeStyle = drawing.color;
    context.lineWidth = drawing.size;
    context.lineCap = 'round';
    context.lineJoin = 'round';

    if (drawing.tool === 'highlighter') {
      context.globalAlpha = 0.4;
      context.lineWidth = drawing.size * 3;
    } else if (drawing.tool === 'laser') {
      context.shadowColor = drawing.color;
      context.shadowBlur = 10;
      context.globalAlpha = 0.8;
    }

    if (drawing.tool === 'pen' || drawing.tool === 'highlighter' || drawing.tool === 'laser') {
      context.beginPath();
      context.moveTo(drawing.points[0].x, drawing.points[0].y);
      
      for (let i = 1; i < drawing.points.length; i++) {
        context.lineTo(drawing.points[i].x, drawing.points[i].y);
      }
      context.stroke();
    } else if (drawing.tool === 'rectangle') {
      const start = drawing.points[0];
      const end = drawing.points[drawing.points.length - 1];
      const width = end.x - start.x;
      const height = end.y - start.y;
      
      context.strokeRect(start.x, start.y, width, height);
    } else if (drawing.tool === 'circle') {
      const start = drawing.points[0];
      const end = drawing.points[drawing.points.length - 1];
      const radius = Math.sqrt(Math.pow(end.x - start.x, 2) + Math.pow(end.y - start.y, 2));
      
      context.beginPath();
      context.arc(start.x, start.y, radius, 0, 2 * Math.PI);
      context.stroke();
    } else if (drawing.tool === 'arrow') {
      const start = drawing.points[0];
      const end = drawing.points[drawing.points.length - 1];
      
      // Draw line
      context.beginPath();
      context.moveTo(start.x, start.y);
      context.lineTo(end.x, end.y);
      context.stroke();
      
      // Draw arrowhead
      const angle = Math.atan2(end.y - start.y, end.x - start.x);
      const arrowLength = 20;
      const arrowAngle = Math.PI / 6;
      
      context.beginPath();
      context.moveTo(end.x, end.y);
      context.lineTo(
        end.x - arrowLength * Math.cos(angle - arrowAngle),
        end.y - arrowLength * Math.sin(angle - arrowAngle)
      );
      context.moveTo(end.x, end.y);
      context.lineTo(
        end.x - arrowLength * Math.cos(angle + arrowAngle),
        end.y - arrowLength * Math.sin(angle + arrowAngle)
      );
      context.stroke();
    }

    context.restore();
  };

  const getMousePos = useCallback((e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return { x: 0, y: 0 };

    const rect = canvas.getBoundingClientRect();
    const scaleX = canvas.width / rect.width;
    const scaleY = canvas.height / rect.height;

    return {
      x: (e.clientX - rect.left) * scaleX,
      y: (e.clientY - rect.top) * scaleY
    };
  }, []);

  const handleMouseDown = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (selectedTool === 'eraser') return;

    const pos = getMousePos(e);
    setIsDrawing(true);
    setCurrentPath([pos]);

    // Save current state for undo
    setUndoStack(prev => [...prev, drawings]);
    setRedoStack([]);
  };

  const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!isDrawing) return;

    const pos = getMousePos(e);
    
    if (selectedTool === 'pen' || selectedTool === 'highlighter' || selectedTool === 'laser') {
      setCurrentPath(prev => [...prev, pos]);
    } else {
      // For shapes, only keep start and current position
      setCurrentPath(prev => [prev[0], pos]);
    }
  };

  const handleMouseUp = () => {
    if (!isDrawing || currentPath.length === 0) return;

    const newDrawing: DrawingData = {
      tool: selectedTool,
      color: selectedColor,
      size: brushSize,
      points: [...currentPath],
      timestamp: Date.now()
    };

    setDrawings(prev => [...prev, newDrawing]);
    setCurrentPath([]);
    setIsDrawing(false);
  };

  const handleUndo = () => {
    if (undoStack.length === 0) return;

    const previousState = undoStack[undoStack.length - 1];
    setRedoStack(prev => [...prev, drawings]);
    setDrawings(previousState);
    setUndoStack(prev => prev.slice(0, -1));
  };

  const handleRedo = () => {
    if (redoStack.length === 0) return;

    const nextState = redoStack[redoStack.length - 1];
    setUndoStack(prev => [...prev, drawings]);
    setDrawings(nextState);
    setRedoStack(prev => prev.slice(0, -1));
  };

  const handleClear = () => {
    setUndoStack(prev => [...prev, drawings]);
    setRedoStack([]);
    setDrawings([]);
  };

  const handleSave = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const link = document.createElement('a');
    link.download = `annotation-${Date.now()}.png`;
    link.href = canvas.toDataURL();
    link.click();
  };

  if (!isActive) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 bg-black/90 z-50 flex flex-col"
      >
        {/* Top Toolbar */}
        <div className="bg-gray-900/95 backdrop-blur-sm border-b border-gray-700 p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <h2 className="text-lg font-semibold text-white">Screen Annotation</h2>
              
              {/* Tool Selection */}
              <div className="flex items-center space-x-2">
                {tools.map((tool) => (
                  <Button
                    key={tool.id}
                    variant={selectedTool === tool.id ? "default" : "outline"}
                    size="sm"
                    onClick={() => setSelectedTool(tool.id)}
                    className="flex items-center space-x-1"
                    title={tool.name}
                  >
                    {tool.icon}
                  </Button>
                ))}
              </div>

              {/* Color Palette */}
              <div className="flex items-center space-x-2">
                <Palette className="h-4 w-4 text-gray-400" />
                <div className="flex space-x-1">
                  {colors.map((color) => (
                    <button
                      key={color}
                      onClick={() => setSelectedColor(color)}
                      className={`w-6 h-6 rounded-full border-2 transition-all ${
                        selectedColor === color 
                          ? 'border-white scale-110' 
                          : 'border-gray-600 hover:scale-105'
                      }`}
                      style={{ backgroundColor: color }}
                    />
                  ))}
                </div>
              </div>

              {/* Brush Size */}
              <div className="flex items-center space-x-2">
                <span className="text-sm text-gray-400">Size:</span>
                <input
                  type="range"
                  min="1"
                  max="20"
                  value={brushSize}
                  onChange={(e) => setBrushSize(Number(e.target.value))}
                  className="w-20"
                />
                <span className="text-sm text-white w-6">{brushSize}</span>
              </div>
            </div>

            <div className="flex items-center space-x-2">
              {/* Action Buttons */}
              <Button
                variant="outline"
                size="sm"
                onClick={handleUndo}
                disabled={undoStack.length === 0}
                title="Undo"
              >
                <Undo className="h-4 w-4" />
              </Button>
              
              <Button
                variant="outline"
                size="sm"
                onClick={handleRedo}
                disabled={redoStack.length === 0}
                title="Redo"
              >
                <Redo className="h-4 w-4" />
              </Button>

              <Button
                variant="outline"
                size="sm"
                onClick={handleClear}
                title="Clear All"
              >
                <Eraser className="h-4 w-4" />
              </Button>

              <Button
                variant="outline"
                size="sm"
                onClick={handleSave}
                title="Save Annotation"
              >
                <Download className="h-4 w-4" />
              </Button>

              <Button
                variant="outline"
                size="sm"
                onClick={onClose}
                title="Close Annotation"
              >
                <X className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>

        {/* Main Drawing Area */}
        <div className="flex-1 relative overflow-hidden">
          {/* Screen Content */}
          {screenStream && (
            <video
              ref={videoRef}
              autoPlay
              muted
              className="absolute inset-0 w-full h-full object-contain pointer-events-none"
            />
          )}

          {/* Drawing Canvas */}
          <canvas
            ref={canvasRef}
            width={1920}
            height={1080}
            className="absolute inset-0 w-full h-full cursor-crosshair"
            style={{ cursor: tools.find(t => t.id === selectedTool)?.cursor }}
            onMouseDown={handleMouseDown}
            onMouseMove={handleMouseMove}
            onMouseUp={handleMouseUp}
            onMouseLeave={() => setIsDrawing(false)}
          />

          {/* Laser Pointer Effect */}
          {selectedTool === 'laser' && (
            <div className="absolute inset-0 pointer-events-none">
              <motion.div
                className="w-4 h-4 rounded-full bg-red-500 shadow-lg shadow-red-500/50"
                style={{
                  position: 'absolute',
                  transform: 'translate(-50%, -50%)',
                }}
                animate={{
                  scale: [1, 1.2, 1],
                  opacity: [0.8, 1, 0.8],
                }}
                transition={{
                  duration: 1,
                  repeat: Infinity,
                  ease: "easeInOut"
                }}
              />
            </div>
          )}
        </div>

        {/* Bottom Status Bar */}
        <div className="bg-gray-900/95 backdrop-blur-sm border-t border-gray-700 p-2">
          <div className="flex items-center justify-between text-sm text-gray-400">
            <div className="flex items-center space-x-4">
              <span>Tool: {tools.find(t => t.id === selectedTool)?.name}</span>
              <span>Color: {selectedColor}</span>
              <span>Size: {brushSize}px</span>
            </div>
            <div className="flex items-center space-x-4">
              <span>Drawings: {drawings.length}</span>
              <span>Press ESC to exit</span>
            </div>
          </div>
        </div>
      </motion.div>
    </AnimatePresence>
  );
}