import { useState, useRef, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Mic, 
  MicOff, 
  Video, 
  VideoOff,
  Monitor,
  Pin,
  Volume2,
  Hand,
  MoreVertical,
  Signal,
  SignalLow,
  SignalHigh,
  Wifi,
  WifiOff
} from 'lucide-react';
import type { Participant } from '@shared/schema';

interface ParticipantTile extends Participant {
  videoStream?: MediaStream;
  audioLevel?: number;
  isPresenting?: boolean;
  isPinned?: boolean;
}

interface VideoTilesProps {
  participants: ParticipantTile[];
  currentUserId: string;
  layout: 'grid' | 'speaker' | 'gallery';
  onParticipantAction: (participantId: string, action: string) => void;
  showAudioIndicators?: boolean;
  showConnectionQuality?: boolean;
}

export default function VideoTiles({
  participants,
  currentUserId,
  layout,
  onParticipantAction,
  showAudioIndicators = true,
  showConnectionQuality = true,
}: VideoTilesProps) {
  const [hoveredParticipant, setHoveredParticipant] = useState<string | null>(null);
  const [audioLevels, setAudioLevels] = useState<Record<string, number>>({});

  // Mock audio level detection
  useEffect(() => {
    const interval = setInterval(() => {
      const newLevels: Record<string, number> = {};
      participants.forEach(p => {
        if (!p.isMuted) {
          newLevels[p.id.toString()] = Math.random() * 100;
        }
      });
      setAudioLevels(newLevels);
    }, 500);

    return () => clearInterval(interval);
  }, [participants]);

  const getGridCols = () => {
    const count = participants.length;
    if (count <= 1) return 'grid-cols-1';
    if (count <= 2) return 'grid-cols-2';
    if (count <= 4) return 'grid-cols-2';
    if (count <= 6) return 'grid-cols-3';
    return 'grid-cols-4';
  };

  const getInitials = (name: string) => {
    return name.split(' ').map(n => n[0]).join('').toUpperCase();
  };

  const getConnectionIcon = (quality: string) => {
    switch (quality) {
      case 'excellent':
        return <Signal className="h-3 w-3 text-green-400" />;
      case 'good':
        return <SignalHigh className="h-3 w-3 text-yellow-400" />;
      case 'fair':
        return <SignalLow className="h-3 w-3 text-orange-400" />;
      case 'poor':
        return <WifiOff className="h-3 w-3 text-red-400" />;
      default:
        return <Wifi className="h-3 w-3 text-gray-400" />;
    }
  };

  return (
    <div className="h-full bg-gray-900">
      <motion.div
        key={layout}
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.2 }}
        className="h-full"
      >
        <div className={`grid ${getGridCols()} gap-4 h-full p-4`}>
          {participants.map((participant) => (
            <ParticipantVideo
              key={participant.id}
              participant={participant}
              isCurrentUser={participant.id.toString() === currentUserId}
              audioLevel={audioLevels[participant.id.toString()] || 0}
              onAction={onParticipantAction}
              showAudioIndicators={showAudioIndicators}
              showConnectionQuality={showConnectionQuality}
              onHover={setHoveredParticipant}
              isHovered={hoveredParticipant === participant.id.toString()}
            />
          ))}
        </div>
      </motion.div>
    </div>
  );
}

interface ParticipantVideoProps {
  participant: ParticipantTile;
  isCurrentUser: boolean;
  audioLevel: number;
  onAction: (participantId: string, action: string) => void;
  showAudioIndicators: boolean;
  showConnectionQuality: boolean;
  onHover: (participantId: string | null) => void;
  isHovered: boolean;
}

function ParticipantVideo({
  participant,
  isCurrentUser,
  audioLevel,
  onAction,
  showAudioIndicators,
  showConnectionQuality,
  onHover,
  isHovered,
}: ParticipantVideoProps) {
  const videoRef = useRef<HTMLVideoElement>(null);

  useEffect(() => {
    if (videoRef.current && participant.videoStream) {
      videoRef.current.srcObject = participant.videoStream;
    }
  }, [participant.videoStream]);

  const getInitials = (name: string) => {
    return name.split(' ').map(n => n[0]).join('').toUpperCase();
  };

  const getConnectionIcon = (quality: string) => {
    switch (quality) {
      case 'excellent':
        return <Signal className="h-3 w-3 text-green-400" />;
      case 'good':
        return <SignalHigh className="h-3 w-3 text-yellow-400" />;
      case 'fair':
        return <SignalLow className="h-3 w-3 text-orange-400" />;
      case 'poor':
        return <WifiOff className="h-3 w-3 text-red-400" />;
      default:
        return <Wifi className="h-3 w-3 text-gray-400" />;
    }
  };

  return (
    <motion.div
      layout
      className={`relative bg-gray-800 rounded-lg overflow-hidden border-2 transition-all duration-200 min-h-[120px] ${
        isCurrentUser 
          ? 'border-blue-500/50' 
          : participant.isHandRaised 
          ? 'border-yellow-500/70 shadow-yellow-500/20 shadow-lg' 
          : participant.isPinned
          ? 'border-purple-500/50'
          : 'border-gray-700'
      }`}
      onMouseEnter={() => onHover(participant.id.toString())}
      onMouseLeave={() => onHover(null)}
      whileHover={{ scale: 1.02 }}
      transition={{ type: 'spring', stiffness: 300, damping: 30 }}
    >
      {/* Video/Avatar */}
      <div className="relative w-full h-full">
        {participant.isVideoEnabled && participant.videoStream ? (
          <video
            ref={videoRef}
            autoPlay
            muted={isCurrentUser}
            playsInline
            className="w-full h-full object-cover"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-gray-700 to-gray-800">
            <Avatar className="h-12 w-12 border-2 border-white/20">
              <AvatarFallback className="bg-gray-600 text-white text-lg font-semibold">
                {getInitials(participant.name)}
              </AvatarFallback>
            </Avatar>
          </div>
        )}

        {/* Screen Share Indicator */}
        {participant.isScreenSharing && (
          <div className="absolute top-2 left-2">
            <Badge className="bg-green-500/90 text-white text-xs">
              <Monitor className="h-3 w-3 mr-1" />
              Sharing
            </Badge>
          </div>
        )}

        {/* Hand Raised */}
        {participant.isHandRaised && (
          <motion.div
            className="absolute top-2 right-2"
            animate={{ rotate: [0, -10, 10, 0] }}
            transition={{ repeat: Infinity, duration: 2 }}
          >
            <div className="bg-yellow-500/90 rounded-full p-2">
              <Hand className="h-4 w-4 text-white" />
            </div>
          </motion.div>
        )}

        {/* Audio Level Indicator */}
        {showAudioIndicators && !participant.isMuted && audioLevel > 10 && (
          <div className="absolute top-2 left-2">
            <motion.div
              className="bg-green-500/80 rounded-full p-1"
              animate={{ scale: [1, 1.2, 1] }}
              transition={{ 
                repeat: Infinity, 
                duration: 0.8,
                ease: "easeInOut"
              }}
            >
              <Volume2 className="h-3 w-3 text-white" />
            </motion.div>
          </div>
        )}

        {/* Bottom Info Bar */}
        <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <span className="text-white font-medium text-xs truncate max-w-[120px]">
                {participant.name}
                {isCurrentUser && ' (You)'}
              </span>
              
              {participant.role === 'host' && (
                <Badge variant="secondary" className="text-xs bg-blue-500/80 text-white">
                  Host
                </Badge>
              )}
            </div>

            <div className="flex items-center space-x-1">
              {/* Microphone Status */}
              <div className={`p-1 rounded ${participant.isMuted ? 'bg-red-500/80' : 'bg-green-500/80'}`}>
                {participant.isMuted ? (
                  <MicOff className="h-3 w-3 text-white" />
                ) : (
                  <Mic className="h-3 w-3 text-white" />
                )}
              </div>

              {/* Video Status */}
              <div className={`p-1 rounded ${!participant.isVideoEnabled ? 'bg-red-500/80' : 'bg-green-500/80'}`}>
                {participant.isVideoEnabled ? (
                  <Video className="h-3 w-3 text-white" />
                ) : (
                  <VideoOff className="h-3 w-3 text-white" />
                )}
              </div>

              {/* Connection Quality */}
              {showConnectionQuality && (
                <div className="p-1">
                  {getConnectionIcon(participant.connectionQuality)}
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Hover Actions */}
        <AnimatePresence>
          {isHovered && !isCurrentUser && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 bg-black/20 flex items-center justify-center"
            >
              <div className="flex space-x-2">
                <Button
                  size="sm"
                  variant="secondary"
                  onClick={() => onAction(participant.id.toString(), 'pin')}
                  className="bg-white/20 backdrop-blur-sm border-white/30 text-white hover:bg-white/30"
                >
                  <Pin className="h-4 w-4" />
                </Button>
                <Button
                  size="sm"
                  variant="secondary"
                  onClick={() => onAction(participant.id.toString(), 'mute')}
                  className="bg-white/20 backdrop-blur-sm border-white/30 text-white hover:bg-white/30"
                >
                  {participant.isMuted ? <Mic className="h-4 w-4" /> : <MicOff className="h-4 w-4" />}
                </Button>
                <Button
                  size="sm"
                  variant="secondary"
                  onClick={() => onAction(participant.id.toString(), 'more')}
                  className="bg-white/20 backdrop-blur-sm border-white/30 text-white hover:bg-white/30"
                >
                  <MoreVertical className="h-4 w-4" />
                </Button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </motion.div>
  );
}