import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Brain, 
  Clock, 
  Users, 
  MessageSquare, 
  TrendingUp,
  Eye,
  Mic,
  Volume2,
  Target,
  AlertCircle,
  CheckCircle,
  BarChart3,
  PieChart,
  Activity,
  Star,
  Download,
  Share
} from 'lucide-react';

interface ParticipantInsight {
  id: string;
  name: string;
  talkTime: number;
  interruptions: number;
  sentiment: 'positive' | 'neutral' | 'negative';
  engagement: number;
  keyTopics: string[];
}

interface MeetingMetric {
  label: string;
  value: string | number;
  trend: 'up' | 'down' | 'stable';
  icon: React.ReactNode;
}

interface ActionItem {
  id: string;
  text: string;
  assignee: string;
  priority: 'high' | 'medium' | 'low';
  dueDate?: string;
  status: 'pending' | 'completed';
}

interface MeetingInsightsProps {
  participants: any[];
  duration: number;
  isRecording: boolean;
}

export default function MeetingInsights({
  participants,
  duration,
  isRecording
}: MeetingInsightsProps) {
  const [insights, setInsights] = useState<ParticipantInsight[]>([]);
  const [actionItems, setActionItems] = useState<ActionItem[]>([]);
  const [keyTopics, setKeyTopics] = useState<string[]>([]);
  const [meetingScore, setMeetingScore] = useState(85);
  const [activeTab, setActiveTab] = useState('overview');

  // Simulate real-time insights generation
  useEffect(() => {
    const interval = setInterval(() => {
      const mockInsights: ParticipantInsight[] = participants.map((p, i) => ({
        id: p.id.toString(),
        name: p.name,
        talkTime: Math.random() * 100,
        interruptions: Math.floor(Math.random() * 5),
        sentiment: ['positive', 'neutral', 'negative'][Math.floor(Math.random() * 3)] as any,
        engagement: Math.floor(Math.random() * 100),
        keyTopics: ['Budget', 'Timeline', 'Resources'].slice(0, Math.floor(Math.random() * 3) + 1)
      }));
      
      setInsights(mockInsights);
      
      // Generate action items
      const mockActions: ActionItem[] = [
        { id: '1', text: 'Follow up on budget approval', assignee: 'John Doe', priority: 'high', status: 'pending' },
        { id: '2', text: 'Schedule next team meeting', assignee: 'Jane Smith', priority: 'medium', status: 'pending' },
        { id: '3', text: 'Review project timeline', assignee: 'Mike Johnson', priority: 'medium', status: 'completed' }
      ];
      setActionItems(mockActions);
      
      setKeyTopics(['Project Budget', 'Timeline Discussion', 'Resource Allocation', 'Next Steps']);
      setMeetingScore(Math.floor(Math.random() * 20) + 80);
    }, 5000);

    return () => clearInterval(interval);
  }, [participants]);

  const metrics: MeetingMetric[] = [
    {
      label: 'Meeting Score',
      value: `${meetingScore}/100`,
      trend: 'up',
      icon: <Star className="h-4 w-4" />
    },
    {
      label: 'Engagement',
      value: '87%',
      trend: 'up',
      icon: <Activity className="h-4 w-4" />
    },
    {
      label: 'Talk Time Balance',
      value: 'Good',
      trend: 'stable',
      icon: <Users className="h-4 w-4" />
    },
    {
      label: 'Interruptions',
      value: insights.reduce((acc, p) => acc + p.interruptions, 0),
      trend: 'down',
      icon: <AlertCircle className="h-4 w-4" />
    }
  ];

  const getTrendColor = (trend: string) => {
    switch (trend) {
      case 'up': return 'text-green-400';
      case 'down': return 'text-red-400';
      default: return 'text-gray-400';
    }
  };

  const getTrendIcon = (trend: string) => {
    switch (trend) {
      case 'up': return '↗';
      case 'down': return '↘';
      default: return '→';
    }
  };

  const getSentimentColor = (sentiment: string) => {
    switch (sentiment) {
      case 'positive': return 'bg-green-500/20 text-green-400 border-green-500/30';
      case 'negative': return 'bg-red-500/20 text-red-400 border-red-500/30';
      default: return 'bg-gray-500/20 text-gray-400 border-gray-500/30';
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return 'bg-red-500/20 text-red-400 border-red-500/30';
      case 'medium': return 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30';
      default: return 'bg-green-500/20 text-green-400 border-green-500/30';
    }
  };

  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <Card className="bg-gray-800/50 border-gray-700 h-full">
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Brain className="h-5 w-5 text-purple-400" />
            <span className="text-white">Meeting Insights</span>
            {isRecording && (
              <Badge className="bg-red-500/20 text-red-400 border-red-500/30">
                <div className="w-2 h-2 bg-red-400 rounded-full mr-2 animate-pulse" />
                Live Analysis
              </Badge>
            )}
          </div>
          <div className="flex items-center space-x-2">
            <Button variant="outline" size="sm">
              <Download className="h-4 w-4 mr-1" />
              Export
            </Button>
            <Button variant="outline" size="sm">
              <Share className="h-4 w-4 mr-1" />
              Share
            </Button>
          </div>
        </CardTitle>
      </CardHeader>

      <CardContent>
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
          <TabsList className="grid w-full grid-cols-4 bg-gray-700">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="participants">Participants</TabsTrigger>
            <TabsTrigger value="topics">Topics</TabsTrigger>
            <TabsTrigger value="actions">Actions</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-4">
            {/* Key Metrics */}
            <div className="grid grid-cols-2 gap-4">
              {metrics.map((metric, index) => (
                <motion.div
                  key={metric.label}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className="bg-gray-700/50 rounded-lg p-4"
                >
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center space-x-2">
                      <div className="text-gray-400">{metric.icon}</div>
                      <span className="text-sm text-gray-300">{metric.label}</span>
                    </div>
                    <span className={`text-xs ${getTrendColor(metric.trend)}`}>
                      {getTrendIcon(metric.trend)}
                    </span>
                  </div>
                  <div className="text-xl font-semibold text-white">{metric.value}</div>
                </motion.div>
              ))}
            </div>

            {/* Real-time Chart */}
            <div className="bg-gray-700/50 rounded-lg p-4">
              <h4 className="text-sm font-medium text-white mb-3 flex items-center space-x-2">
                <BarChart3 className="h-4 w-4" />
                <span>Speaking Time Distribution</span>
              </h4>
              <div className="space-y-2">
                {insights.map((participant) => (
                  <div key={participant.id} className="space-y-1">
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-gray-300">{participant.name}</span>
                      <span className="text-gray-400">{Math.round(participant.talkTime)}%</span>
                    </div>
                    <div className="w-full bg-gray-600 rounded-full h-2">
                      <motion.div
                        className="bg-blue-500 h-2 rounded-full"
                        initial={{ width: 0 }}
                        animate={{ width: `${participant.talkTime}%` }}
                        transition={{ duration: 0.5 }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Meeting Quality Score */}
            <div className="bg-gray-700/50 rounded-lg p-4">
              <h4 className="text-sm font-medium text-white mb-3 flex items-center space-x-2">
                <Target className="h-4 w-4" />
                <span>Meeting Quality Score</span>
              </h4>
              <div className="flex items-center justify-center">
                <div className="relative w-24 h-24">
                  <svg className="w-24 h-24 transform -rotate-90" viewBox="0 0 36 36">
                    <path
                      d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      className="text-gray-600"
                    />
                    <motion.path
                      d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeDasharray={`${meetingScore}, 100`}
                      className="text-green-400"
                      initial={{ strokeDasharray: "0, 100" }}
                      animate={{ strokeDasharray: `${meetingScore}, 100` }}
                      transition={{ duration: 1 }}
                    />
                  </svg>
                  <div className="absolute inset-0 flex items-center justify-center">
                    <span className="text-xl font-semibold text-white">{meetingScore}</span>
                  </div>
                </div>
              </div>
              <div className="text-center mt-2">
                <div className="text-sm text-gray-400">Excellent meeting quality</div>
                <div className="text-xs text-gray-500">Based on engagement, balance, and sentiment</div>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="participants" className="space-y-4">
            <div className="space-y-3">
              {insights.map((participant) => (
                <motion.div
                  key={participant.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  className="bg-gray-700/50 rounded-lg p-4"
                >
                  <div className="flex items-center justify-between mb-3">
                    <h4 className="font-medium text-white">{participant.name}</h4>
                    <Badge className={getSentimentColor(participant.sentiment)}>
                      {participant.sentiment}
                    </Badge>
                  </div>

                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <span className="text-gray-400">Talk Time:</span>
                      <span className="text-white ml-2">{Math.round(participant.talkTime)}%</span>
                    </div>
                    <div>
                      <span className="text-gray-400">Engagement:</span>
                      <span className="text-white ml-2">{participant.engagement}%</span>
                    </div>
                    <div>
                      <span className="text-gray-400">Interruptions:</span>
                      <span className="text-white ml-2">{participant.interruptions}</span>
                    </div>
                  </div>

                  {participant.keyTopics.length > 0 && (
                    <div className="mt-3">
                      <span className="text-gray-400 text-sm">Key Topics:</span>
                      <div className="flex flex-wrap gap-1 mt-1">
                        {participant.keyTopics.map((topic, index) => (
                          <Badge key={index} variant="secondary" className="text-xs">
                            {topic}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  )}
                </motion.div>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="topics" className="space-y-4">
            <div className="bg-gray-700/50 rounded-lg p-4">
              <h4 className="text-sm font-medium text-white mb-3 flex items-center space-x-2">
                <MessageSquare className="h-4 w-4" />
                <span>Key Discussion Topics</span>
              </h4>
              <div className="space-y-2">
                {keyTopics.map((topic, index) => (
                  <motion.div
                    key={topic}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.1 }}
                    className="flex items-center justify-between p-3 bg-gray-600/50 rounded-lg"
                  >
                    <span className="text-white">{topic}</span>
                    <div className="flex items-center space-x-2">
                      <Badge variant="secondary" className="text-xs">
                        {Math.floor(Math.random() * 10) + 5} mentions
                      </Badge>
                      <div className="w-16 bg-gray-600 rounded-full h-2">
                        <div 
                          className="bg-blue-500 h-2 rounded-full"
                          style={{ width: `${Math.random() * 100}%` }}
                        />
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>

            <div className="bg-gray-700/50 rounded-lg p-4">
              <h4 className="text-sm font-medium text-white mb-3">Sentiment Analysis</h4>
              <div className="grid grid-cols-3 gap-4">
                <div className="text-center">
                  <div className="text-2xl font-semibold text-green-400">65%</div>
                  <div className="text-xs text-gray-400">Positive</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-semibold text-gray-400">25%</div>
                  <div className="text-xs text-gray-400">Neutral</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-semibold text-red-400">10%</div>
                  <div className="text-xs text-gray-400">Negative</div>
                </div>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="actions" className="space-y-4">
            <div className="space-y-3">
              {actionItems.map((action) => (
                <motion.div
                  key={action.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  className="bg-gray-700/50 rounded-lg p-4"
                >
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center space-x-2 mb-2">
                        {action.status === 'completed' ? (
                          <CheckCircle className="h-4 w-4 text-green-400" />
                        ) : (
                          <Clock className="h-4 w-4 text-yellow-400" />
                        )}
                        <span className={`text-sm ${action.status === 'completed' ? 'line-through text-gray-400' : 'text-white'}`}>
                          {action.text}
                        </span>
                      </div>
                      <div className="flex items-center space-x-2 text-xs text-gray-400">
                        <span>Assigned to: {action.assignee}</span>
                        {action.dueDate && <span>Due: {action.dueDate}</span>}
                      </div>
                    </div>
                    <Badge className={getPriorityColor(action.priority)}>
                      {action.priority}
                    </Badge>
                  </div>
                </motion.div>
              ))}
            </div>

            <Button className="w-full bg-blue-600 hover:bg-blue-700">
              <MessageSquare className="h-4 w-4 mr-2" />
              Generate Meeting Summary
            </Button>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}