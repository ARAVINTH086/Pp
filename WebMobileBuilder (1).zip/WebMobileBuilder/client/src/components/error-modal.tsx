import { Button } from '@/components/ui/button';
import { AlertTriangle } from 'lucide-react';

interface ErrorModalProps {
  title: string;
  message: string;
  onRetry: () => void;
  onBackToLobby: () => void;
}

export default function ErrorModal({ title, message, onRetry, onBackToLobby }: ErrorModalProps) {
  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center">
      <div className="bg-gray-800 rounded-xl p-8 text-center max-w-md mx-4 border border-red-500/50">
        <div className="w-16 h-16 bg-red-500/20 rounded-full flex items-center justify-center mx-auto mb-4">
          <AlertTriangle className="h-8 w-8 text-red-500" />
        </div>
        <h3 className="text-xl font-semibold mb-2 text-white">{title}</h3>
        <p className="text-gray-400 mb-6">{message}</p>
        
        <div className="space-y-3">
          <Button 
            onClick={onRetry}
            className="w-full bg-blue-500 hover:bg-blue-600 text-white font-semibold"
          >
            Try Again
          </Button>
          <Button 
            onClick={onBackToLobby}
            variant="outline"
            className="w-full bg-gray-600 hover:bg-gray-500 text-white border-gray-500"
          >
            Back to Lobby
          </Button>
        </div>
      </div>
    </div>
  );
}
