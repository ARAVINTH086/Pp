import { Check, Circle } from 'lucide-react';

interface LoadingStep {
  text: string;
  completed: boolean;
}

interface LoadingOverlayProps {
  status: string;
  steps: LoadingStep[];
}

export default function LoadingOverlay({ status, steps }: LoadingOverlayProps) {
  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center">
      <div className="bg-gray-800 rounded-xl p-8 text-center max-w-md mx-4 border border-gray-700">
        <div className="w-16 h-16 border-4 border-blue-500 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
        <h3 className="text-xl font-semibold mb-2 text-white">Connecting...</h3>
        <p className="text-gray-400 mb-6">{status}</p>
        
        {/* Connection Steps */}
        <div className="space-y-2 text-left">
          {steps.map((step, index) => (
            <div key={index} className="flex items-center space-x-3 text-sm">
              {step.completed ? (
                <Check className="h-4 w-4 text-green-500" />
              ) : (
                <div className="w-4 h-4 border-2 border-blue-500 border-t-transparent rounded-full animate-spin"></div>
              )}
              <span className={step.completed ? 'text-white' : 'text-gray-400'}>
                {step.text}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
