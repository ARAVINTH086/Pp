import { useState, useEffect, useRef } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Slider } from '@/components/ui/slider';
import { Badge } from '@/components/ui/badge';
import { motion } from 'framer-motion';
import { 
  Volume2, 
  VolumeX, 
  Settings, 
  BarChart3, 
  Zap,
  Shield,
  Brain,
  Mic,
  Users,
  Wind,
  Car,
  Home,
  Headphones
} from 'lucide-react';

interface NoiseProfile {
  id: string;
  name: string;
  description: string;
  icon: React.ReactNode;
  settings: {
    suppression: number;
    sensitivity: number;
    adaptation: number;
  };
}

interface NoiseCancellationProps {
  isEnabled: boolean;
  onToggle: (enabled: boolean) => void;
  audioLevel: number;
  onSettingsChange: (settings: any) => void;
}

export default function NoiseCancellation({
  isEnabled,
  onToggle,
  audioLevel,
  onSettingsChange
}: NoiseCancellationProps) {
  const [selectedProfile, setSelectedProfile] = useState('balanced');
  const [customSettings, setCustomSettings] = useState({
    noiseGate: 20,
    echoCancellation: 80,
    autoGainControl: 60,
    highpassFilter: 40,
    adaptiveMode: true,
    realTimeProcessing: true
  });
  const [noiseLevel, setNoiseLevel] = useState(0);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const analysisRef = useRef<NodeJS.Timeout>();

  const noiseProfiles: NoiseProfile[] = [
    {
      id: 'meeting',
      name: 'Meeting Room',
      description: 'Optimized for conference rooms and office environments',
      icon: <Users className="h-5 w-5" />,
      settings: { suppression: 70, sensitivity: 60, adaptation: 80 }
    },
    {
      id: 'home',
      name: 'Home Office',
      description: 'Reduces household noises like air conditioning, typing',
      icon: <Home className="h-5 w-5" />,
      settings: { suppression: 60, sensitivity: 70, adaptation: 60 }
    },
    {
      id: 'outdoor',
      name: 'Outdoor/Mobile',
      description: 'Handles wind, traffic, and environmental sounds',
      icon: <Wind className="h-5 w-5" />,
      settings: { suppression: 85, sensitivity: 80, adaptation: 90 }
    },
    {
      id: 'transport',
      name: 'Transportation',
      description: 'Airplane, train, or car environments',
      icon: <Car className="h-5 w-5" />,
      settings: { suppression: 90, sensitivity: 75, adaptation: 85 }
    },
    {
      id: 'studio',
      name: 'Studio Quality',
      description: 'Professional audio processing for content creation',
      icon: <Headphones className="h-5 w-5" />,
      settings: { suppression: 95, sensitivity: 90, adaptation: 70 }
    },
    {
      id: 'balanced',
      name: 'Balanced',
      description: 'General purpose noise reduction for most scenarios',
      icon: <Shield className="h-5 w-5" />,
      settings: { suppression: 75, sensitivity: 65, adaptation: 75 }
    }
  ];

  // Simulate noise level detection
  useEffect(() => {
    if (isEnabled) {
      setIsAnalyzing(true);
      analysisRef.current = setInterval(() => {
        const baseNoise = Math.random() * 30;
        const processedNoise = isEnabled ? baseNoise * 0.3 : baseNoise;
        setNoiseLevel(processedNoise);
      }, 500);
    } else {
      setIsAnalyzing(false);
      if (analysisRef.current) {
        clearInterval(analysisRef.current);
      }
    }

    return () => {
      if (analysisRef.current) {
        clearInterval(analysisRef.current);
      }
    };
  }, [isEnabled]);

  const handleProfileChange = (profileId: string) => {
    setSelectedProfile(profileId);
    const profile = noiseProfiles.find(p => p.id === profileId);
    if (profile) {
      onSettingsChange({
        profile: profileId,
        settings: profile.settings
      });
    }
  };

  const handleCustomSettingChange = (key: string, value: number | boolean) => {
    const newSettings = { ...customSettings, [key]: value };
    setCustomSettings(newSettings);
    onSettingsChange({
      profile: 'custom',
      customSettings: newSettings
    });
  };

  const getNoiseReductionLevel = () => {
    if (!isEnabled) return 0;
    const profile = noiseProfiles.find(p => p.id === selectedProfile);
    return profile ? profile.settings.suppression : 75;
  };

  const getNoiseColor = (level: number) => {
    if (level < 20) return 'text-green-400';
    if (level < 40) return 'text-yellow-400';
    if (level < 60) return 'text-orange-400';
    return 'text-red-400';
  };

  return (
    <Card className="bg-gray-800/50 border-gray-700">
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Brain className="h-5 w-5 text-purple-400" />
            <span className="text-white">AI Noise Cancellation</span>
            {isEnabled && (
              <Badge className="bg-green-500/20 text-green-400 border-green-500/30">
                Active
              </Badge>
            )}
          </div>
          <Switch checked={isEnabled} onCheckedChange={onToggle} />
        </CardTitle>
      </CardHeader>

      <CardContent className="space-y-6">
        {/* Noise Level Visualization */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-sm text-gray-300">Current Noise Level</span>
            <span className={`text-sm font-mono ${getNoiseColor(noiseLevel)}`}>
              {Math.round(noiseLevel)}dB
            </span>
          </div>
          
          <div className="relative h-2 bg-gray-700 rounded-full overflow-hidden">
            <motion.div
              className="absolute left-0 top-0 h-full bg-gradient-to-r from-green-400 via-yellow-400 to-red-400"
              style={{ width: `${(noiseLevel / 100) * 100}%` }}
              animate={{ width: `${(noiseLevel / 100) * 100}%` }}
              transition={{ duration: 0.3 }}
            />
          </div>

          {isEnabled && (
            <div className="flex items-center justify-between text-xs text-gray-400">
              <span>Reduction: {getNoiseReductionLevel()}%</span>
              <span className="flex items-center space-x-1">
                <Zap className="h-3 w-3" />
                <span>AI Processing</span>
              </span>
            </div>
          )}
        </div>

        {/* Audio Visualization */}
        <div className="space-y-2">
          <div className="flex items-center space-x-2">
            <BarChart3 className="h-4 w-4 text-blue-400" />
            <span className="text-sm text-gray-300">Audio Signal</span>
          </div>
          
          <div className="grid grid-cols-20 gap-1 h-8">
            {Array.from({ length: 20 }, (_, i) => {
              const height = Math.sin((Date.now() / 100 + i) * 0.5) * 0.5 + 0.5;
              const scaledHeight = isEnabled ? height * (1 - noiseLevel / 200) : height;
              
              return (
                <motion.div
                  key={i}
                  className={`bg-gradient-to-t ${
                    isEnabled 
                      ? 'from-blue-600 to-blue-400' 
                      : 'from-gray-600 to-gray-400'
                  } rounded-sm`}
                  animate={{ height: `${scaledHeight * 100}%` }}
                  transition={{ duration: 0.1 }}
                />
              );
            })}
          </div>
        </div>

        {/* Noise Profiles */}
        {isEnabled && (
          <div className="space-y-3">
            <h4 className="text-sm font-medium text-white flex items-center space-x-2">
              <Settings className="h-4 w-4" />
              <span>Noise Profiles</span>
            </h4>
            
            <div className="grid grid-cols-2 gap-2">
              {noiseProfiles.map((profile) => (
                <motion.button
                  key={profile.id}
                  onClick={() => handleProfileChange(profile.id)}
                  className={`p-3 rounded-lg border transition-all text-left ${
                    selectedProfile === profile.id
                      ? 'border-blue-500 bg-blue-500/10'
                      : 'border-gray-600 bg-gray-700/50 hover:border-gray-500'
                  }`}
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                >
                  <div className="flex items-center space-x-2 mb-1">
                    <div className={`${
                      selectedProfile === profile.id ? 'text-blue-400' : 'text-gray-400'
                    }`}>
                      {profile.icon}
                    </div>
                    <span className={`text-sm font-medium ${
                      selectedProfile === profile.id ? 'text-blue-400' : 'text-white'
                    }`}>
                      {profile.name}
                    </span>
                  </div>
                  <p className="text-xs text-gray-400 line-clamp-2">
                    {profile.description}
                  </p>
                </motion.button>
              ))}
            </div>
          </div>
        )}

        {/* Advanced Settings */}
        {isEnabled && selectedProfile === 'custom' && (
          <div className="space-y-4 p-4 bg-gray-700/30 rounded-lg">
            <h4 className="text-sm font-medium text-white">Advanced Settings</h4>
            
            <div className="space-y-3">
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <label className="text-sm text-gray-300">Noise Gate</label>
                  <span className="text-xs text-gray-400">{customSettings.noiseGate}%</span>
                </div>
                <Slider
                  value={[customSettings.noiseGate]}
                  onValueChange={([value]) => handleCustomSettingChange('noiseGate', value)}
                  max={100}
                  step={1}
                  className="w-full"
                />
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <label className="text-sm text-gray-300">Echo Cancellation</label>
                  <span className="text-xs text-gray-400">{customSettings.echoCancellation}%</span>
                </div>
                <Slider
                  value={[customSettings.echoCancellation]}
                  onValueChange={([value]) => handleCustomSettingChange('echoCancellation', value)}
                  max={100}
                  step={1}
                  className="w-full"
                />
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <label className="text-sm text-gray-300">Auto Gain Control</label>
                  <span className="text-xs text-gray-400">{customSettings.autoGainControl}%</span>
                </div>
                <Slider
                  value={[customSettings.autoGainControl]}
                  onValueChange={([value]) => handleCustomSettingChange('autoGainControl', value)}
                  max={100}
                  step={1}
                  className="w-full"
                />
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <label className="text-sm text-gray-300">High-pass Filter</label>
                  <span className="text-xs text-gray-400">{customSettings.highpassFilter}Hz</span>
                </div>
                <Slider
                  value={[customSettings.highpassFilter]}
                  onValueChange={([value]) => handleCustomSettingChange('highpassFilter', value)}
                  max={200}
                  step={5}
                  className="w-full"
                />
              </div>

              <div className="flex items-center justify-between">
                <label className="text-sm text-gray-300">Adaptive Mode</label>
                <Switch
                  checked={customSettings.adaptiveMode}
                  onCheckedChange={(checked) => handleCustomSettingChange('adaptiveMode', checked)}
                />
              </div>

              <div className="flex items-center justify-between">
                <label className="text-sm text-gray-300">Real-time Processing</label>
                <Switch
                  checked={customSettings.realTimeProcessing}
                  onCheckedChange={(checked) => handleCustomSettingChange('realTimeProcessing', checked)}
                />
              </div>
            </div>
          </div>
        )}

        {/* Performance Stats */}
        {isEnabled && (
          <div className="grid grid-cols-3 gap-4 pt-4 border-t border-gray-700">
            <div className="text-center">
              <div className="text-lg font-semibold text-green-400">
                {getNoiseReductionLevel()}%
              </div>
              <div className="text-xs text-gray-400">Noise Reduced</div>
            </div>
            
            <div className="text-center">
              <div className="text-lg font-semibold text-blue-400">
                ~2ms
              </div>
              <div className="text-xs text-gray-400">Latency</div>
            </div>
            
            <div className="text-center">
              <div className="text-lg font-semibold text-purple-400">
                AI
              </div>
              <div className="text-xs text-gray-400">Processing</div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}