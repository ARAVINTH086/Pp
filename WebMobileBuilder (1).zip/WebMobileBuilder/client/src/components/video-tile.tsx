import { useEffect, useRef } from 'react';
import { User, Mic, MicOff, Video, VideoOff } from 'lucide-react';
import type { Participant } from '@/hooks/use-webrtc';

interface VideoTileProps {
  participant: Participant;
  isLocal?: boolean;
}

export default function VideoTile({ participant, isLocal = false }: VideoTileProps) {
  const videoRef = useRef<HTMLVideoElement>(null);

  useEffect(() => {
    if (videoRef.current && participant.stream) {
      videoRef.current.srcObject = participant.stream;
    }
  }, [participant.stream]);

  const getConnectionQuality = () => {
    // Mock connection quality - in real implementation, this would come from WebRTC stats
    const qualities = ['excellent', 'good', 'fair', 'poor'];
    return qualities[Math.floor(Math.random() * qualities.length)];
  };

  const quality = getConnectionQuality();

  return (
    <div className="relative bg-gray-700 rounded-lg overflow-hidden aspect-video group">
      {participant.isVideoEnabled && participant.stream ? (
        <video
          ref={videoRef}
          autoPlay
          playsInline
          muted={isLocal} // Mute local video to prevent feedback
          className="w-full h-full object-cover"
        />
      ) : (
        <div className="absolute inset-0 bg-gray-700 flex flex-col items-center justify-center">
          <div className="w-16 h-16 bg-gray-600 rounded-full flex items-center justify-center mb-2">
            <User className="text-2xl text-gray-400" />
          </div>
          <span className="text-sm text-gray-300">{participant.name}</span>
        </div>
      )}
      
      {/* User Info Overlay */}
      <div className="absolute bottom-2 left-2 bg-black/70 rounded-md px-2 py-1 text-sm flex items-center space-x-2">
        <span className="text-white text-xs">
          {isLocal ? 'You' : participant.name}
        </span>
        {participant.isMuted ? (
          <MicOff className="text-red-500 h-3 w-3" />
        ) : (
          <Mic className="text-green-500 h-3 w-3" />
        )}
        {!participant.isVideoEnabled && (
          <VideoOff className="text-red-500 h-3 w-3" />
        )}
      </div>
      
      {/* Connection Quality Indicator */}
      <div className="absolute top-2 right-2 flex space-x-1">
        <div className={`w-1 h-3 rounded-full ${
          quality === 'poor' ? 'bg-red-500' : 
          quality === 'fair' ? 'bg-yellow-500' : 'bg-green-500'
        }`} />
        <div className={`w-1 h-2 rounded-full ${
          quality === 'poor' || quality === 'fair' ? 'bg-gray-600' : 
          quality === 'good' ? 'bg-yellow-500' : 'bg-green-500'
        }`} />
        <div className={`w-1 h-4 rounded-full ${
          quality === 'excellent' ? 'bg-green-500' : 'bg-gray-600'
        }`} />
      </div>
      
      {/* Video disabled overlay */}
      {!participant.isVideoEnabled && (
        <div className="absolute inset-0 bg-gradient-to-br from-gray-600 to-gray-800 flex items-center justify-center">
          <VideoOff className="text-gray-400 h-8 w-8" />
        </div>
      )}
    </div>
  );
}
