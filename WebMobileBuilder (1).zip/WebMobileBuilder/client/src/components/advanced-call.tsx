import { useState, useEffect, useRef } from 'react';
import { useLocation, useRoute } from 'wouter';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Mic, 
  MicOff, 
  Video, 
  VideoOff, 
  Phone, 
  Monitor, 
  Settings,
  Users,
  MessageSquare,
  Sparkles,
  Brain,
  Palette,
  Hand,
  MoreVertical,
  Grid3X3,
  Maximize,
  Volume2,
  Shield
} from 'lucide-react';

// Import our advanced components
import VideoTiles from '@/components/video-tiles';
import ChatPanel from '@/components/chat-panel';
import AITranscriptionPanel from '@/components/ai-transcription-panel';
import VirtualBackgrounds from '@/components/virtual-backgrounds';
import ScreenAnnotation from '@/components/screen-annotation';
import NoiseCancellation from '@/components/noise-cancellation';
import MeetingInsights from '@/components/meeting-insights';

interface AdvancedCallProps {
  roomId: string;
  userId: string;
  userName: string;
}

export default function AdvancedCall({ roomId, userId, userName }: AdvancedCallProps) {
  const [, setLocation] = useLocation();
  const [isAudioEnabled, setIsAudioEnabled] = useState(true);
  const [isVideoEnabled, setIsVideoEnabled] = useState(true);
  const [isScreenSharing, setIsScreenSharing] = useState(false);
  const [isHandRaised, setIsHandRaised] = useState(false);
  const [showChat, setShowChat] = useState(false);
  const [showTranscription, setShowTranscription] = useState(false);
  const [showInsights, setShowInsights] = useState(false);
  const [showBackgrounds, setShowBackgrounds] = useState(false);
  const [showAnnotation, setShowAnnotation] = useState(false);
  const [showNoiseCancellation, setShowNoiseCancellation] = useState(false);
  const [layout, setLayout] = useState<'grid' | 'speaker' | 'gallery'>('grid');
  const [participants, setParticipants] = useState([
    {
      id: 1,
      name: userName,
      isVideoEnabled: true,
      isMuted: false,
      isScreenSharing: false,
      isHandRaised: false,
      role: 'host',
      connectionQuality: 'excellent'
    },
    {
      id: 2,
      name: 'Alice Johnson',
      isVideoEnabled: true,
      isMuted: false,
      isScreenSharing: false,
      isHandRaised: false,
      role: 'participant',
      connectionQuality: 'good'
    },
    {
      id: 3,
      name: 'Bob Smith',
      isVideoEnabled: false,
      isMuted: true,
      isScreenSharing: false,
      isHandRaised: true,
      role: 'participant',
      connectionQuality: 'fair'
    }
  ]);
  const [callDuration, setCallDuration] = useState(0);
  const [currentBackground, setCurrentBackground] = useState(null);
  const [screenStream, setScreenStream] = useState<MediaStream | undefined>();
  const [isRecording, setIsRecording] = useState(false);

  const callStartTime = useRef(Date.now());

  // Update call duration
  useEffect(() => {
    const interval = setInterval(() => {
      setCallDuration(Math.floor((Date.now() - callStartTime.current) / 1000));
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  const handleEndCall = () => {
    // In a real app, this would clean up WebRTC connections
    setLocation('/lobby');
  };

  const handleToggleAudio = () => {
    setIsAudioEnabled(!isAudioEnabled);
    setParticipants(prev => 
      prev.map(p => p.id.toString() === userId ? { ...p, isMuted: isAudioEnabled } : p)
    );
  };

  const handleToggleVideo = () => {
    setIsVideoEnabled(!isVideoEnabled);
    setParticipants(prev => 
      prev.map(p => p.id.toString() === userId ? { ...p, isVideoEnabled: !isVideoEnabled } : p)
    );
  };

  const handleScreenShare = async () => {
    if (!isScreenSharing) {
      try {
        const stream = await navigator.mediaDevices.getDisplayMedia({
          video: true,
          audio: true
        });
        setScreenStream(stream);
        setIsScreenSharing(true);
        setParticipants(prev => 
          prev.map(p => p.id.toString() === userId ? { ...p, isScreenSharing: true } : p)
        );
      } catch (error) {
        console.error('Failed to start screen sharing:', error);
      }
    } else {
      if (screenStream) {
        screenStream.getTracks().forEach(track => track.stop());
      }
      setScreenStream(undefined);
      setIsScreenSharing(false);
      setParticipants(prev => 
        prev.map(p => p.id.toString() === userId ? { ...p, isScreenSharing: false } : p)
      );
    }
  };

  const handleRaiseHand = () => {
    setIsHandRaised(!isHandRaised);
    setParticipants(prev => 
      prev.map(p => p.id.toString() === userId ? { ...p, isHandRaised: !isHandRaised } : p)
    );
  };

  const handleParticipantAction = (participantId: string, action: string) => {
    console.log(`Action ${action} for participant ${participantId}`);
    // Handle participant actions like pin, mute, etc.
  };

  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const sidebarWidth = (showChat ? 320 : 0) + (showTranscription ? 320 : 0) + (showInsights ? 320 : 0);

  return (
    <div className="h-screen bg-gray-900 flex flex-col overflow-hidden">
      {/* Top Bar */}
      <div className="bg-gray-800/90 backdrop-blur-sm border-b border-gray-700 p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <h1 className="text-lg font-semibold text-white">VideoConnect Pro</h1>
            <div className="flex items-center space-x-2 text-sm text-gray-300">
              <span>Room: {roomId}</span>
              <span>•</span>
              <span>{formatDuration(callDuration)}</span>
              <span>•</span>
              <div className="flex items-center space-x-1">
                <Users className="h-4 w-4" />
                <span>{participants.length}</span>
              </div>
            </div>
            {isRecording && (
              <div className="flex items-center space-x-2 bg-red-500/20 text-red-400 px-3 py-1 rounded-full">
                <div className="w-2 h-2 bg-red-400 rounded-full animate-pulse" />
                <span className="text-sm">Recording</span>
              </div>
            )}
          </div>

          <div className="flex items-center space-x-2">
            {/* Layout Controls */}
            <div className="flex items-center space-x-1 bg-gray-700/50 rounded-lg p-1">
              <Button
                variant={layout === 'grid' ? 'default' : 'ghost'}
                size="sm"
                onClick={() => setLayout('grid')}
                title="Grid View"
              >
                <Grid3X3 className="h-4 w-4" />
              </Button>
              <Button
                variant={layout === 'speaker' ? 'default' : 'ghost'}
                size="sm"
                onClick={() => setLayout('speaker')}
                title="Speaker View"
              >
                <Maximize className="h-4 w-4" />
              </Button>
              <Button
                variant={layout === 'gallery' ? 'default' : 'ghost'}
                size="sm"
                onClick={() => setLayout('gallery')}
                title="Gallery View"
              >
                <Users className="h-4 w-4" />
              </Button>
            </div>

            {/* Advanced Features */}
            <Button
              variant={showChat ? 'default' : 'outline'}
              size="sm"
              onClick={() => setShowChat(!showChat)}
              title="Chat Panel"
            >
              <MessageSquare className="h-4 w-4" />
            </Button>

            <Button
              variant={showTranscription ? 'default' : 'outline'}
              size="sm"
              onClick={() => setShowTranscription(!showTranscription)}
              title="AI Transcription"
            >
              <Brain className="h-4 w-4" />
            </Button>

            <Button
              variant={showInsights ? 'default' : 'outline'}
              size="sm"
              onClick={() => setShowInsights(!showInsights)}
              title="Meeting Insights"
            >
              <Sparkles className="h-4 w-4" />
            </Button>

            <Button
              variant="outline"
              size="sm"
              onClick={() => setShowBackgrounds(true)}
              title="Virtual Backgrounds"
            >
              <Palette className="h-4 w-4" />
            </Button>

            <Button
              variant={showNoiseCancellation ? 'default' : 'outline'}
              size="sm"
              onClick={() => setShowNoiseCancellation(!showNoiseCancellation)}
              title="Noise Cancellation"
            >
              <Shield className="h-4 w-4" />
            </Button>

            <Button
              variant="outline"
              size="sm"
              onClick={() => setIsRecording(!isRecording)}
              title="Record Meeting"
            >
              <div className={`w-3 h-3 rounded-full ${isRecording ? 'bg-red-500' : 'bg-gray-400'}`} />
            </Button>
          </div>
        </div>
      </div>

      {/* Main Content Area */}
      <div className="flex-1 flex overflow-hidden">
        {/* Video Area */}
        <div 
          className="flex-1 transition-all duration-300"
          style={{ width: `calc(100% - ${sidebarWidth}px)` }}
        >
          <VideoTiles
            participants={participants}
            currentUserId={userId}
            layout={layout}
            onParticipantAction={handleParticipantAction}
          />
        </div>

        {/* Sidebar Panels */}
        <AnimatePresence>
          {showChat && (
            <motion.div
              initial={{ width: 0, opacity: 0 }}
              animate={{ width: 320, opacity: 1 }}
              exit={{ width: 0, opacity: 0 }}
              transition={{ duration: 0.3 }}
              className="border-l border-gray-700 bg-gray-800"
            >
              <ChatPanel
                currentUserId={userId}
                participants={participants}
                roomId={roomId}
                onClose={() => setShowChat(false)}
              />
            </motion.div>
          )}

          {showTranscription && (
            <motion.div
              initial={{ width: 0, opacity: 0 }}
              animate={{ width: 320, opacity: 1 }}
              exit={{ width: 0, opacity: 0 }}
              transition={{ duration: 0.3 }}
              className="border-l border-gray-700 bg-gray-800"
            >
              <AITranscriptionPanel
                isActive={true}
                participants={participants}
                onClose={() => setShowTranscription(false)}
              />
            </motion.div>
          )}

          {showInsights && (
            <motion.div
              initial={{ width: 0, opacity: 0 }}
              animate={{ width: 320, opacity: 1 }}
              exit={{ width: 0, opacity: 0 }}
              transition={{ duration: 0.3 }}
              className="border-l border-gray-700 bg-gray-800"
            >
              <MeetingInsights
                participants={participants}
                duration={callDuration}
                isRecording={isRecording}
              />
            </motion.div>
          )}
        </AnimatePresence>

        {/* Noise Cancellation Panel */}
        <AnimatePresence>
          {showNoiseCancellation && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 20 }}
              className="absolute bottom-20 right-4 w-80 z-40"
            >
              <NoiseCancellation
                isEnabled={true}
                onToggle={() => {}}
                audioLevel={50}
                onSettingsChange={() => {}}
              />
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Bottom Control Bar */}
      <div className="bg-gray-800/90 backdrop-blur-sm border-t border-gray-700 p-4">
        <div className="flex items-center justify-center space-x-4">
          {/* Audio Control */}
          <Button
            variant={isAudioEnabled ? 'outline' : 'destructive'}
            size="lg"
            onClick={handleToggleAudio}
            className="rounded-full w-12 h-12"
            title={isAudioEnabled ? 'Mute' : 'Unmute'}
          >
            {isAudioEnabled ? <Mic className="h-5 w-5" /> : <MicOff className="h-5 w-5" />}
          </Button>

          {/* Video Control */}
          <Button
            variant={isVideoEnabled ? 'outline' : 'destructive'}
            size="lg"
            onClick={handleToggleVideo}
            className="rounded-full w-12 h-12"
            title={isVideoEnabled ? 'Turn off camera' : 'Turn on camera'}
          >
            {isVideoEnabled ? <Video className="h-5 w-5" /> : <VideoOff className="h-5 w-5" />}
          </Button>

          {/* Screen Share */}
          <Button
            variant={isScreenSharing ? 'default' : 'outline'}
            size="lg"
            onClick={handleScreenShare}
            className="rounded-full w-12 h-12"
            title={isScreenSharing ? 'Stop sharing' : 'Share screen'}
          >
            <Monitor className="h-5 w-5" />
          </Button>

          {/* Raise Hand */}
          <Button
            variant={isHandRaised ? 'default' : 'outline'}
            size="lg"
            onClick={handleRaiseHand}
            className="rounded-full w-12 h-12"
            title={isHandRaised ? 'Lower hand' : 'Raise hand'}
          >
            <Hand className="h-5 w-5" />
          </Button>

          {/* Screen Annotation */}
          <Button
            variant={showAnnotation ? 'default' : 'outline'}
            size="lg"
            onClick={() => setShowAnnotation(!showAnnotation)}
            className="rounded-full w-12 h-12"
            title="Annotate screen"
          >
            <Sparkles className="h-5 w-5" />
          </Button>

          {/* Settings */}
          <Button
            variant="outline"
            size="lg"
            className="rounded-full w-12 h-12"
            title="Settings"
          >
            <Settings className="h-5 w-5" />
          </Button>

          {/* More Options */}
          <Button
            variant="outline"
            size="lg"
            className="rounded-full w-12 h-12"
            title="More options"
          >
            <MoreVertical className="h-5 w-5" />
          </Button>

          {/* End Call */}
          <Button
            variant="destructive"
            size="lg"
            onClick={handleEndCall}
            className="rounded-full w-12 h-12 bg-red-600 hover:bg-red-700"
            title="End call"
          >
            <Phone className="h-5 w-5 rotate-180" />
          </Button>
        </div>
      </div>

      {/* Modal Components */}
      <VirtualBackgrounds
        isOpen={showBackgrounds}
        onClose={() => setShowBackgrounds(false)}
        onApplyBackground={setCurrentBackground}
        currentBackground={currentBackground}
      />

      <ScreenAnnotation
        isActive={showAnnotation}
        onClose={() => setShowAnnotation(false)}
        screenStream={screenStream}
      />
    </div>
  );
}