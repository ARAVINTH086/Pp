import { useState, useRef, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Image, 
  Upload, 
  Sparkles, 
  Cpu, 
  Eye, 
  EyeOff,
  Trash2,
  Download,
  Zap,
  Palette,
  Mountain,
  Building,
  Home,
  Waves,
  Sunset,
  TreePine
} from 'lucide-react';

interface VirtualBackground {
  id: string;
  name: string;
  type: 'blur' | 'image' | 'video' | 'ai-generated';
  url?: string;
  thumbnail: string;
  category: 'professional' | 'casual' | 'nature' | 'abstract' | 'custom';
  isPremium?: boolean;
}

interface VirtualBackgroundsProps {
  isOpen: boolean;
  onClose: () => void;
  onApplyBackground: (background: VirtualBackground | null) => void;
  currentBackground: VirtualBackground | null;
}

export default function VirtualBackgrounds({
  isOpen,
  onClose,
  onApplyBackground,
  currentBackground
}: VirtualBackgroundsProps) {
  const [selectedCategory, setSelectedCategory] = useState<string>('professional');
  const [uploadedBackgrounds, setUploadedBackgrounds] = useState<VirtualBackground[]>([]);
  const [isGeneratingAI, setIsGeneratingAI] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const predefinedBackgrounds: VirtualBackground[] = [
    {
      id: 'blur-light',
      name: 'Light Blur',
      type: 'blur',
      thumbnail: 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTAwIiBoZWlnaHQ9IjYwIiB2aWV3Qm94PSIwIDAgMTAwIDYwIiBmaWxsPSJub25lIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxyZWN0IHdpZHRoPSIxMDAiIGhlaWdodD0iNjAiIGZpbGw9InVybCgjZ3JhZGllbnQwKSIvPjxkZWZzPjxsaW5lYXJHcmFkaWVudCBpZD0iZ3JhZGllbnQwIiB4MT0iMCUiIHkxPSIwJSIgeDI9IjEwMCUiIHkyPSIxMDAlIj48c3RvcCBvZmZzZXQ9IjAlIiBzdG9wLWNvbG9yPSIjZjNmNGY2Ii8+PHN0b3Agb2Zmc2V0PSIxMDAlIiBzdG9wLWNvbG9yPSIjZTVlN2ViIi8+PC9saW5lYXJHcmFkaWVudD48L2RlZnM+PC9zdmc+',
      category: 'professional'
    },
    {
      id: 'office-modern',
      name: 'Modern Office',
      type: 'image',
      thumbnail: 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTAwIiBoZWlnaHQ9IjYwIiB2aWV3Qm94PSIwIDAgMTAwIDYwIiBmaWxsPSJub25lIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxyZWN0IHdpZHRoPSIxMDAiIGhlaWdodD0iNjAiIGZpbGw9IiNmOGZhZmMiLz48cmVjdCB4PSIxMCIgeT0iMjAiIHdpZHRoPSI4MCIgaGVpZ2h0PSIyMCIgZmlsbD0iIzNiODJmNiIgb3BhY2l0eT0iMC4yIi8+PHJlY3QgeD0iMjAiIHk9IjEwIiB3aWR0aD0iNjAiIGhlaWdodD0iNDAiIGZpbGw9IiM2MzY2ZjEiIG9wYWNpdHk9IjAuMSIvPjwvc3ZnPg==',
      category: 'professional'
    },
    {
      id: 'library-classic',
      name: 'Classic Library',
      type: 'image',
      thumbnail: 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTAwIiBoZWlnaHQ9IjYwIiB2aWV3Qm94PSIwIDAgMTAwIDYwIiBmaWxsPSJub25lIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxyZWN0IHdpZHRoPSIxMDAiIGhlaWdodD0iNjAiIGZpbGw9IiM3YzJkMTIiLz48cmVjdCB4PSIwIiB5PSIwIiB3aWR0aD0iMTAwIiBoZWlnaHQ9IjEwIiBmaWxsPSIjOTI0MDBkIi8+PHJlY3QgeD0iMTAiIHk9IjE1IiB3aWR0aD0iMzAiIGhlaWdodD0iNDAiIGZpbGw9IiNkOTc3MDYiLz48L3N2Zz4=',
      category: 'professional'
    },
    {
      id: 'coffee-shop',
      name: 'Coffee Shop',
      type: 'image',
      thumbnail: 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTAwIiBoZWlnaHQ9IjYwIiB2aWV3Qm94PSIwIDAgMTAwIDYwIiBmaWxsPSJub25lIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxyZWN0IHdpZHRoPSIxMDAiIGhlaWdodD0iNjAiIGZpbGw9IiNmMGY5ZmYiLz48Y2lyY2xlIGN4PSI3NSIgY3k9IjE1IiByPSI4IiBmaWxsPSIjZmJiZjI0Ii8+PHJlY3QgeD0iMjAiIHk9IjMwIiB3aWR0aD0iNjAiIGhlaWdodD0iMjAiIGZpbGw9IiM4Yjc0NjMiLz48L3N2Zz4=',
      category: 'casual'
    },
    {
      id: 'mountain-vista',
      name: 'Mountain Vista',
      type: 'image',
      thumbnail: 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTAwIiBoZWlnaHQ9IjYwIiB2aWV3Qm94PSIwIDAgMTAwIDYwIiBmaWxsPSJub25lIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxyZWN0IHdpZHRoPSIxMDAiIGhlaWdodD0iNjAiIGZpbGw9InVybCgjc2t5KSIvPjxwb2x5Z29uIHBvaW50cz0iMCw2MCAyNSwzMCA1MCw0MCA3NSwyNSAxMDAsNjAiIGZpbGw9IiM2MzY2ZjEiLz48ZGVmcz48bGluZWFyR3JhZGllbnQgaWQ9InNreSIgeDE9IjAlIiB5MT0iMCUiIHgyPSIwJSIgeTI9IjEwMCUiPjxzdG9wIG9mZnNldD0iMCUiIHN0b3AtY29sb3I9IiM3ZGQ3ZjAiLz48c3RvcCBvZmZzZXQ9IjEwMCUiIHN0b3AtY29sb3I9IiNmMGY5ZmYiLz48L2xpbmVhckdyYWRpZW50PjwvZGVmcz48L3N2Zz4=',
      category: 'nature'
    },
    {
      id: 'ocean-waves',
      name: 'Ocean Waves',
      type: 'video',
      thumbnail: 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTAwIiBoZWlnaHQ9IjYwIiB2aWV3Qm94PSIwIDAgMTAwIDYwIiBmaWxsPSJub25lIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxyZWN0IHdpZHRoPSIxMDAiIGhlaWdodD0iNjAiIGZpbGw9InVybCgjb2NlYW4pIi8+PHBhdGggZD0iTTAsNDBRMjUsMzAgNTAsNDBUMTAwLDQwVjYwSDBaIiBmaWxsPSIjMTBiOTgxIiBvcGFjaXR5PSIwLjMiLz48ZGVmcz48bGluZWFyR3JhZGllbnQgaWQ9Im9jZWFuIiB4MT0iMCUiIHkxPSIwJSIgeDI9IjAlIiB5Mj0iMTAwJSI+PHN0b3Agb2Zmc2V0PSIwJSIgc3RvcC1jb2xvcj0iIzBmNzJhMCIvPjxzdG9wIG9mZnNldD0iMTAwJSIgc3RvcC1jb2xvcj0iIzE2NWU4NSIvPjwvbGluZWFyR3JhZGllbnQ+PC9kZWZzPjwvc3ZnPg==',
      category: 'nature'
    }
  ];

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'professional': return <Building className="h-4 w-4" />;
      case 'casual': return <Home className="h-4 w-4" />;
      case 'nature': return <TreePine className="h-4 w-4" />;
      case 'abstract': return <Palette className="h-4 w-4" />;
      case 'custom': return <Upload className="h-4 w-4" />;
      default: return <Image className="h-4 w-4" />;
    }
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        const newBackground: VirtualBackground = {
          id: `custom-${Date.now()}`,
          name: file.name.split('.')[0],
          type: 'image',
          url: e.target?.result as string,
          thumbnail: e.target?.result as string,
          category: 'custom'
        };
        setUploadedBackgrounds(prev => [...prev, newBackground]);
      };
      reader.readAsDataURL(file);
    }
  };

  const generateAIBackground = async () => {
    setIsGeneratingAI(true);
    // Simulate AI generation delay
    await new Promise(resolve => setTimeout(resolve, 3000));
    
    const aiBackground: VirtualBackground = {
      id: `ai-${Date.now()}`,
      name: 'AI Generated Space',
      type: 'ai-generated',
      thumbnail: 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTAwIiBoZWlnaHQ9IjYwIiB2aWV3Qm94PSIwIDAgMTAwIDYwIiBmaWxsPSJub25lIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxyZWN0IHdpZHRoPSIxMDAiIGhlaWdodD0iNjAiIGZpbGw9InVybCgjYWkpIi8+PGNpcmNsZSBjeD0iMjAiIGN5PSIxNSIgcj0iMiIgZmlsbD0iI2ZiYmYyNCIvPjxjaXJjbGUgY3g9IjgwIiBjeT0iNDAiIHI9IjEuNSIgZmlsbD0iI2ZiYmYyNCIvPjxjaXJjbGUgY3g9IjYwIiBjeT0iMjAiIHI9IjEiIGZpbGw9IiNmYmJmMjQiLz48ZGVmcz48cmFkaWFsR3JhZGllbnQgaWQ9ImFpIiBjeD0iNTAlIiBjeT0iNTAlIiByPSI1MCUiPjxzdG9wIG9mZnNldD0iMCUiIHN0b3AtY29sb3I9IiMxZTE5MzciLz48c3RvcCBvZmZzZXQ9IjEwMCUiIHN0b3AtY29sb3I9IiMwZjE0MjkiLz48L3JhZGlhbEdyYWRpZW50PjwvZGVmcz48L3N2Zz4=',
      category: 'abstract',
      isPremium: true
    };
    
    setUploadedBackgrounds(prev => [...prev, aiBackground]);
    setIsGeneratingAI(false);
  };

  const allBackgrounds = [...predefinedBackgrounds, ...uploadedBackgrounds];
  const filteredBackgrounds = allBackgrounds.filter(bg => bg.category === selectedCategory);

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
        onClick={onClose}
      >
        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.9, opacity: 0 }}
          className="bg-gray-900 rounded-xl border border-gray-700 w-full max-w-4xl max-h-[80vh] overflow-hidden"
          onClick={(e) => e.stopPropagation()}
        >
          <div className="p-6 border-b border-gray-700">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-xl font-semibold text-white">Virtual Backgrounds</h2>
                <p className="text-gray-400 text-sm">Choose from professional backgrounds or create your own</p>
              </div>
              <Button
                variant="ghost"
                size="sm"
                onClick={onClose}
                className="text-gray-400 hover:text-white"
              >
                ×
              </Button>
            </div>
          </div>

          <div className="p-6">
            <Tabs value={selectedCategory} onValueChange={setSelectedCategory} className="space-y-6">
              <TabsList className="grid w-full grid-cols-5 bg-gray-800">
                <TabsTrigger value="professional" className="flex items-center space-x-2">
                  <Building className="h-4 w-4" />
                  <span>Professional</span>
                </TabsTrigger>
                <TabsTrigger value="casual" className="flex items-center space-x-2">
                  <Home className="h-4 w-4" />
                  <span>Casual</span>
                </TabsTrigger>
                <TabsTrigger value="nature" className="flex items-center space-x-2">
                  <TreePine className="h-4 w-4" />
                  <span>Nature</span>
                </TabsTrigger>
                <TabsTrigger value="abstract" className="flex items-center space-x-2">
                  <Palette className="h-4 w-4" />
                  <span>Abstract</span>
                </TabsTrigger>
                <TabsTrigger value="custom" className="flex items-center space-x-2">
                  <Upload className="h-4 w-4" />
                  <span>Custom</span>
                </TabsTrigger>
              </TabsList>

              <div className="space-y-4">
                {/* Control Buttons */}
                <div className="flex items-center space-x-4">
                  <Button
                    onClick={() => onApplyBackground(null)}
                    variant={currentBackground === null ? "default" : "outline"}
                    className="flex items-center space-x-2"
                  >
                    <EyeOff className="h-4 w-4" />
                    <span>No Background</span>
                  </Button>

                  <Button
                    onClick={() => fileInputRef.current?.click()}
                    variant="outline"
                    className="flex items-center space-x-2"
                  >
                    <Upload className="h-4 w-4" />
                    <span>Upload Image</span>
                  </Button>

                  <Button
                    onClick={generateAIBackground}
                    disabled={isGeneratingAI}
                    variant="outline"
                    className="flex items-center space-x-2"
                  >
                    {isGeneratingAI ? (
                      <motion.div
                        animate={{ rotate: 360 }}
                        transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                        className="h-4 w-4"
                      >
                        <Cpu className="h-4 w-4" />
                      </motion.div>
                    ) : (
                      <Sparkles className="h-4 w-4" />
                    )}
                    <span>{isGeneratingAI ? 'Generating...' : 'AI Generate'}</span>
                  </Button>

                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*,video/*"
                    onChange={handleFileUpload}
                    className="hidden"
                  />
                </div>

                {/* Background Grid */}
                <div className="grid grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4 max-h-96 overflow-y-auto">
                  {filteredBackgrounds.map((background) => (
                    <motion.div
                      key={background.id}
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      className="relative group cursor-pointer"
                      onClick={() => onApplyBackground(background)}
                    >
                      <Card className={`overflow-hidden border-2 transition-all ${
                        currentBackground?.id === background.id 
                          ? 'border-blue-500 shadow-blue-500/25' 
                          : 'border-gray-700 hover:border-gray-600'
                      }`}>
                        <CardContent className="p-0">
                          <div className="aspect-video relative">
                            <img
                              src={background.thumbnail}
                              alt={background.name}
                              className="w-full h-full object-cover"
                            />
                            
                            {/* Overlay */}
                            <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                              <Eye className="h-6 w-6 text-white" />
                            </div>

                            {/* Type Badge */}
                            <div className="absolute top-2 left-2">
                              <Badge 
                                variant="secondary" 
                                className={`text-xs ${
                                  background.type === 'video' ? 'bg-red-500/80' :
                                  background.type === 'ai-generated' ? 'bg-purple-500/80' :
                                  background.type === 'blur' ? 'bg-blue-500/80' :
                                  'bg-gray-500/80'
                                } text-white`}
                              >
                                {background.type === 'video' && <Waves className="h-3 w-3 mr-1" />}
                                {background.type === 'ai-generated' && <Sparkles className="h-3 w-3 mr-1" />}
                                {background.type === 'blur' && <Zap className="h-3 w-3 mr-1" />}
                                {background.type === 'image' && <Mountain className="h-3 w-3 mr-1" />}
                                {background.type.toUpperCase()}
                              </Badge>
                            </div>

                            {/* Premium Badge */}
                            {background.isPremium && (
                              <div className="absolute top-2 right-2">
                                <Badge className="bg-yellow-500/80 text-white text-xs">
                                  <Sparkles className="h-3 w-3 mr-1" />
                                  PRO
                                </Badge>
                              </div>
                            )}

                            {/* Selected Indicator */}
                            {currentBackground?.id === background.id && (
                              <div className="absolute inset-0 bg-blue-500/20 border-2 border-blue-500 rounded">
                                <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
                                  <div className="bg-blue-500 rounded-full p-1">
                                    <Eye className="h-4 w-4 text-white" />
                                  </div>
                                </div>
                              </div>
                            )}
                          </div>
                        </CardContent>
                      </Card>

                      <div className="mt-2 text-center">
                        <p className="text-xs font-medium text-white truncate">{background.name}</p>
                      </div>
                    </motion.div>
                  ))}

                  {/* Empty State for Custom */}
                  {selectedCategory === 'custom' && uploadedBackgrounds.length === 0 && (
                    <div className="col-span-full flex flex-col items-center justify-center py-12 text-gray-400">
                      <Upload className="h-12 w-12 mb-4" />
                      <p className="text-sm">No custom backgrounds yet</p>
                      <p className="text-xs">Upload images or generate with AI</p>
                    </div>
                  )}
                </div>
              </div>
            </Tabs>
          </div>

          <div className="p-6 bg-gray-800/50 border-t border-gray-700">
            <div className="flex items-center justify-between">
              <div className="text-sm text-gray-400">
                {currentBackground ? `Selected: ${currentBackground.name}` : 'No background selected'}
              </div>
              <div className="flex items-center space-x-2">
                <Button variant="outline" onClick={onClose}>
                  Cancel
                </Button>
                <Button onClick={onClose} className="bg-blue-600 hover:bg-blue-700">
                  Apply
                </Button>
              </div>
            </div>
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}