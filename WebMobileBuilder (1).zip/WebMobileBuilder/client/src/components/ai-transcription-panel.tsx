import { useState, useRef, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { 
  Mic, 
  MicOff, 
  Download, 
  Search, 
  Copy, 
  Brain,
  Languages,
  X,
  Play,
  Pause,
  SkipBack,
  SkipForward,
  Zap
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import type { AiTranscript } from '@shared/schema';

interface AiTranscriptionPanelProps {
  roomId: string;
  isOpen: boolean;
  onClose: () => void;
  participants: Array<{ id: string; name: string; }>;
}

interface TranscriptSegment extends AiTranscript {
  isLive?: boolean;
  aiSummary?: string;
  keywords?: string[];
  sentiment?: 'positive' | 'neutral' | 'negative';
}

export default function AiTranscriptionPanel({ 
  roomId, 
  isOpen, 
  onClose,
  participants 
}: AiTranscriptionPanelProps) {
  const [transcripts, setTranscripts] = useState<TranscriptSegment[]>([]);
  const [isRecording, setIsRecording] = useState(false);
  const [currentLanguage, setCurrentLanguage] = useState('en');
  const [showLiveTranscription, setShowLiveTranscription] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedSpeaker, setSelectedSpeaker] = useState<string | null>(null);
  const [aiInsights, setAiInsights] = useState(true);
  const [currentTranscript, setCurrentTranscript] = useState('');
  const scrollAreaRef = useRef<HTMLDivElement>(null);

  // Mock transcription data for demo
  useEffect(() => {
    if (isOpen) {
      const mockTranscripts: TranscriptSegment[] = [
        {
          id: 1,
          roomId,
          speakerId: 'user1',
          speakerName: 'Alice Johnson',
          transcript: 'Welcome everyone to today\'s product strategy meeting. I\'m excited to discuss our Q2 roadmap and key initiatives.',
          timestamp: new Date(Date.now() - 300000),
          confidence: 98,
          language: 'en',
          aiSummary: 'Meeting opener discussing Q2 roadmap',
          keywords: ['product strategy', 'Q2 roadmap', 'initiatives'],
          sentiment: 'positive'
        },
        {
          id: 2,
          roomId,
          speakerId: 'user2',
          speakerName: 'Bob Smith',
          transcript: 'Thanks Alice. I want to start by reviewing our user engagement metrics from last quarter. We saw a 23% increase in daily active users.',
          timestamp: new Date(Date.now() - 240000),
          confidence: 95,
          language: 'en',
          aiSummary: 'Reported 23% increase in daily active users',
          keywords: ['user engagement', 'metrics', 'daily active users', '23% increase'],
          sentiment: 'positive'
        },
        {
          id: 3,
          roomId,
          speakerId: 'user3',
          speakerName: 'Carol Lee',
          transcript: 'That\'s fantastic news! However, I\'m concerned about the retention rates in the mobile app. We need to address the onboarding flow issues.',
          timestamp: new Date(Date.now() - 180000),
          confidence: 92,
          language: 'en',
          aiSummary: 'Raised concerns about mobile app retention and onboarding',
          keywords: ['retention rates', 'mobile app', 'onboarding flow'],
          sentiment: 'neutral'
        }
      ];
      setTranscripts(mockTranscripts);
    }
  }, [isOpen, roomId]);

  // Simulate live transcription
  useEffect(() => {
    if (!isRecording || !showLiveTranscription) return;

    const interval = setInterval(() => {
      const words = [
        'And', 'I', 'think', 'we', 'should', 'also', 'consider', 'the', 
        'user', 'feedback', 'from', 'our', 'recent', 'survey'
      ];
      
      setCurrentTranscript(prev => {
        if (prev.split(' ').length >= 10) {
          return words[Math.floor(Math.random() * words.length)];
        }
        return prev + ' ' + words[Math.floor(Math.random() * words.length)];
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [isRecording, showLiveTranscription]);

  const toggleRecording = () => {
    setIsRecording(!isRecording);
    if (!isRecording) {
      setCurrentTranscript('Starting transcription...');
    } else {
      setCurrentTranscript('');
    }
  };

  const exportTranscript = () => {
    const content = transcripts
      .filter(t => !selectedSpeaker || t.speakerId === selectedSpeaker)
      .map(t => `[${formatTime(t.timestamp)}] ${t.speakerName}: ${t.transcript}`)
      .join('\n\n');
    
    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `transcript-${roomId}-${new Date().toISOString().split('T')[0]}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const copyTranscript = () => {
    const content = transcripts
      .filter(t => !selectedSpeaker || t.speakerId === selectedSpeaker)
      .map(t => `${t.speakerName}: ${t.transcript}`)
      .join('\n\n');
    
    navigator.clipboard.writeText(content);
  };

  const formatTime = (timestamp: Date) => {
    return new Date(timestamp).toLocaleTimeString('en-US', { 
      hour: 'numeric', 
      minute: '2-digit',
      second: '2-digit',
      hour12: true 
    });
  };

  const getInitials = (name: string) => {
    return name.split(' ').map(n => n[0]).join('').toUpperCase();
  };

  const getSentimentColor = (sentiment?: string) => {
    switch (sentiment) {
      case 'positive': return 'text-green-400';
      case 'negative': return 'text-red-400';
      default: return 'text-gray-400';
    }
  };

  const filteredTranscripts = transcripts.filter(t => {
    const matchesSearch = !searchQuery || 
      t.transcript.toLowerCase().includes(searchQuery.toLowerCase()) ||
      t.speakerName.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesSpeaker = !selectedSpeaker || t.speakerId === selectedSpeaker;
    return matchesSearch && matchesSpeaker;
  });

  if (!isOpen) return null;

  return (
    <motion.div
      initial={{ x: '100%' }}
      animate={{ x: 0 }}
      exit={{ x: '100%' }}
      transition={{ type: 'spring', damping: 25, stiffness: 200 }}
      className="fixed right-0 top-0 h-full w-96 bg-gray-800 border-l border-gray-700 z-50 flex flex-col"
    >
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b border-gray-700">
        <div className="flex items-center space-x-3">
          <Brain className="h-5 w-5 text-purple-500" />
          <h3 className="text-lg font-semibold text-white">AI Transcription</h3>
          <Badge variant="secondary" className="text-xs bg-purple-500/20 text-purple-300">
            Live
          </Badge>
        </div>
        <Button
          variant="ghost"
          size="sm"
          onClick={onClose}
          className="text-gray-400 hover:text-white"
        >
          <X className="h-4 w-4" />
        </Button>
      </div>

      {/* Controls */}
      <div className="p-4 border-b border-gray-700 space-y-4">
        <div className="flex items-center justify-between">
          <Button
            onClick={toggleRecording}
            className={`flex items-center space-x-2 ${
              isRecording 
                ? 'bg-red-500 hover:bg-red-600' 
                : 'bg-blue-500 hover:bg-blue-600'
            }`}
          >
            {isRecording ? <MicOff className="h-4 w-4" /> : <Mic className="h-4 w-4" />}
            <span>{isRecording ? 'Stop' : 'Start'} Recording</span>
          </Button>
          
          <div className="flex items-center space-x-2">
            <Button variant="ghost" size="sm" onClick={exportTranscript}>
              <Download className="h-4 w-4" />
            </Button>
            <Button variant="ghost" size="sm" onClick={copyTranscript}>
              <Copy className="h-4 w-4" />
            </Button>
          </div>
        </div>

        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Switch
              checked={showLiveTranscription}
              onCheckedChange={setShowLiveTranscription}
            />
            <span className="text-sm text-gray-300">Live transcription</span>
          </div>
          
          <div className="flex items-center space-x-2">
            <Switch
              checked={aiInsights}
              onCheckedChange={setAiInsights}
            />
            <span className="text-sm text-gray-300">AI insights</span>
            <Zap className="h-3 w-3 text-yellow-400" />
          </div>
        </div>

        {/* Language Selector */}
        <div className="flex items-center space-x-2">
          <Languages className="h-4 w-4 text-gray-400" />
          <select 
            value={currentLanguage}
            onChange={(e) => setCurrentLanguage(e.target.value)}
            className="bg-gray-700 border border-gray-600 rounded px-2 py-1 text-sm text-white"
          >
            <option value="en">English</option>
            <option value="es">Spanish</option>
            <option value="fr">French</option>
            <option value="de">German</option>
            <option value="ja">Japanese</option>
          </select>
        </div>

        {/* Speaker Filter */}
        <div className="flex flex-wrap gap-2">
          <Button
            variant={selectedSpeaker === null ? "default" : "ghost"}
            size="sm"
            onClick={() => setSelectedSpeaker(null)}
            className="text-xs"
          >
            All Speakers
          </Button>
          {participants.map(participant => (
            <Button
              key={participant.id}
              variant={selectedSpeaker === participant.id ? "default" : "ghost"}
              size="sm"
              onClick={() => setSelectedSpeaker(participant.id)}
              className="text-xs"
            >
              {participant.name}
            </Button>
          ))}
        </div>
      </div>

      {/* Live Transcription */}
      {showLiveTranscription && isRecording && (
        <div className="p-4 border-b border-gray-700 bg-gray-700/50">
          <div className="flex items-center space-x-2 mb-2">
            <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse" />
            <span className="text-sm text-gray-300">Live</span>
          </div>
          <div className="text-sm text-white min-h-[40px] p-2 bg-gray-600 rounded">
            {currentTranscript || 'Listening...'}
          </div>
        </div>
      )}

      {/* Transcription History */}
      <ScrollArea ref={scrollAreaRef} className="flex-1 p-4">
        <div className="space-y-4">
          <AnimatePresence>
            {filteredTranscripts.map((transcript) => (
              <motion.div
                key={transcript.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="group"
              >
                <div className="flex items-start space-x-3">
                  <Avatar className="h-8 w-8">
                    <AvatarFallback className="bg-gray-600 text-white text-xs">
                      {getInitials(transcript.speakerName)}
                    </AvatarFallback>
                  </Avatar>
                  
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center space-x-2 mb-1">
                      <span className="text-sm font-medium text-white">
                        {transcript.speakerName}
                      </span>
                      <span className="text-xs text-gray-400">
                        {formatTime(transcript.timestamp)}
                      </span>
                      <Badge variant="outline" className="text-xs text-green-400 border-green-400">
                        {transcript.confidence}%
                      </Badge>
                      {transcript.sentiment && (
                        <div className={`w-2 h-2 rounded-full ${
                          transcript.sentiment === 'positive' ? 'bg-green-400' :
                          transcript.sentiment === 'negative' ? 'bg-red-400' : 'bg-gray-400'
                        }`} />
                      )}
                    </div>
                    
                    <div className="bg-gray-700 rounded-lg p-3 text-sm text-gray-100">
                      {transcript.transcript}
                    </div>
                    
                    {/* AI Insights */}
                    {aiInsights && transcript.aiSummary && (
                      <div className="mt-2 p-2 bg-purple-500/10 border border-purple-500/20 rounded text-xs">
                        <div className="flex items-center space-x-1 mb-1">
                          <Zap className="h-3 w-3 text-purple-400" />
                          <span className="text-purple-300 font-medium">AI Summary:</span>
                        </div>
                        <p className="text-purple-200">{transcript.aiSummary}</p>
                        
                        {transcript.keywords && transcript.keywords.length > 0 && (
                          <div className="flex flex-wrap gap-1 mt-2">
                            {transcript.keywords.map((keyword, index) => (
                              <Badge 
                                key={index}
                                variant="outline" 
                                className="text-xs text-purple-300 border-purple-400"
                              >
                                {keyword}
                              </Badge>
                            ))}
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      </ScrollArea>

      {/* Search */}
      <div className="p-4 border-t border-gray-700">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
          <input
            type="text"
            placeholder="Search transcripts..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2 bg-gray-700 border border-gray-600 rounded text-white placeholder-gray-400 text-sm focus:border-purple-500 focus:outline-none"
          />
        </div>
      </div>
    </motion.div>
  );
}