import { useState, useRef, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { 
  Send, 
  Smile, 
  Paperclip, 
  MoreVertical, 
  Reply, 
  Heart,
  ThumbsUp,
  Laugh,
  Angry,
  Frown,
  X,
  Users,
  MessageSquare
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import type { ChatMessage } from '@shared/schema';

interface ChatPanelProps {
  roomId: string;
  userId: string;
  userName: string;
  isOpen: boolean;
  onClose: () => void;
  participants: Array<{ id: string; name: string; }>;
}

const reactionEmojis = [
  { emoji: '👍', icon: ThumbsUp, name: 'thumbs_up' },
  { emoji: '❤️', icon: Heart, name: 'heart' },
  { emoji: '😂', icon: Laugh, name: 'laugh' },
  { emoji: '😢', icon: Frown, name: 'sad' },
  { emoji: '😠', icon: Angry, name: 'angry' },
];

export default function ChatPanel({ 
  roomId, 
  userId, 
  userName, 
  isOpen, 
  onClose,
  participants 
}: ChatPanelProps) {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [typingUsers, setTypingUsers] = useState<string[]>([]);
  const [selectedParticipant, setSelectedParticipant] = useState<string | null>(null);
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);
  const scrollAreaRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // Mock messages for demo
  useEffect(() => {
    if (isOpen) {
      const mockMessages: ChatMessage[] = [
        {
          id: 1,
          roomId,
          userId: 'user1',
          userName: 'Alice Johnson',
          message: 'Hello everyone! Thanks for joining the call.',
          messageType: 'text',
          timestamp: new Date(Date.now() - 300000),
          isPrivate: false,
          recipientId: null,
          fileUrl: null,
          fileName: null,
          reactions: JSON.stringify({ thumbs_up: ['user2', 'user3'], heart: ['user4'] })
        },
        {
          id: 2,
          roomId,
          userId: 'user2',
          userName: 'Bob Smith',
          message: 'Great to be here! Looking forward to our discussion.',
          messageType: 'text',
          timestamp: new Date(Date.now() - 240000),
          isPrivate: false,
          recipientId: null,
          fileUrl: null,
          fileName: null,
          reactions: JSON.stringify({ thumbs_up: ['user1'] })
        }
      ];
      setMessages(mockMessages);
    }
  }, [isOpen, roomId]);

  const sendMessage = () => {
    if (!newMessage.trim()) return;

    const message: ChatMessage = {
      id: Date.now(),
      roomId,
      userId,
      userName,
      message: newMessage.trim(),
      messageType: 'text',
      timestamp: new Date(),
      isPrivate: !!selectedParticipant,
      recipientId: selectedParticipant,
      fileUrl: null,
      fileName: null,
      reactions: '{}'
    };

    setMessages(prev => [...prev, message]);
    setNewMessage('');
    
    // Scroll to bottom
    setTimeout(() => {
      if (scrollAreaRef.current) {
        scrollAreaRef.current.scrollTop = scrollAreaRef.current.scrollHeight;
      }
    }, 100);
  };

  const addReaction = (messageId: number, reactionName: string) => {
    setMessages(prev => prev.map(msg => {
      if (msg.id === messageId) {
        const reactions = JSON.parse(msg.reactions);
        if (!reactions[reactionName]) {
          reactions[reactionName] = [];
        }
        
        if (reactions[reactionName].includes(userId)) {
          reactions[reactionName] = reactions[reactionName].filter((id: string) => id !== userId);
        } else {
          reactions[reactionName].push(userId);
        }
        
        return { ...msg, reactions: JSON.stringify(reactions) };
      }
      return msg;
    }));
  };

  const formatTime = (timestamp: Date) => {
    return new Date(timestamp).toLocaleTimeString('en-US', { 
      hour: 'numeric', 
      minute: '2-digit',
      hour12: true 
    });
  };

  const getInitials = (name: string) => {
    return name.split(' ').map(n => n[0]).join('').toUpperCase();
  };

  if (!isOpen) return null;

  return (
    <motion.div
      initial={{ x: '100%' }}
      animate={{ x: 0 }}
      exit={{ x: '100%' }}
      transition={{ type: 'spring', damping: 25, stiffness: 200 }}
      className="fixed right-0 top-0 h-full w-96 bg-gray-800 border-l border-gray-700 z-50 flex flex-col"
    >
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b border-gray-700">
        <div className="flex items-center space-x-3">
          <MessageSquare className="h-5 w-5 text-blue-500" />
          <h3 className="text-lg font-semibold text-white">
            {selectedParticipant ? 'Private Chat' : 'Meeting Chat'}
          </h3>
          {selectedParticipant && (
            <Badge variant="secondary" className="text-xs">
              {participants.find(p => p.id === selectedParticipant)?.name}
            </Badge>
          )}
        </div>
        <div className="flex items-center space-x-2">
          {selectedParticipant && (
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setSelectedParticipant(null)}
              className="text-gray-400 hover:text-white"
            >
              <Users className="h-4 w-4" />
            </Button>
          )}
          <Button
            variant="ghost"
            size="sm"
            onClick={onClose}
            className="text-gray-400 hover:text-white"
          >
            <X className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {/* Participant Selection */}
      {!selectedParticipant && (
        <div className="p-3 border-b border-gray-700">
          <div className="flex flex-wrap gap-2">
            <Button
              variant="ghost"
              size="sm"
              className="text-xs text-blue-400 hover:bg-blue-500/20"
            >
              Everyone ({participants.length})
            </Button>
            {participants.filter(p => p.id !== userId).map(participant => (
              <Button
                key={participant.id}
                variant="ghost"
                size="sm"
                onClick={() => setSelectedParticipant(participant.id)}
                className="text-xs text-gray-400 hover:bg-gray-700"
              >
                {participant.name}
              </Button>
            ))}
          </div>
        </div>
      )}

      {/* Messages */}
      <ScrollArea ref={scrollAreaRef} className="flex-1 p-4">
        <div className="space-y-4">
          <AnimatePresence>
            {messages
              .filter(msg => !selectedParticipant || 
                (msg.isPrivate && (msg.recipientId === selectedParticipant || msg.userId === selectedParticipant)) ||
                (!msg.isPrivate && !selectedParticipant))
              .map((message) => (
              <motion.div
                key={message.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="group"
              >
                <div className="flex items-start space-x-3">
                  <Avatar className="h-8 w-8">
                    <AvatarFallback className="bg-gray-600 text-white text-xs">
                      {getInitials(message.userName)}
                    </AvatarFallback>
                  </Avatar>
                  
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center space-x-2 mb-1">
                      <span className="text-sm font-medium text-white">
                        {message.userName}
                      </span>
                      {message.isPrivate && (
                        <Badge variant="outline" className="text-xs text-purple-400 border-purple-400">
                          Private
                        </Badge>
                      )}
                      <span className="text-xs text-gray-400">
                        {formatTime(message.timestamp)}
                      </span>
                    </div>
                    
                    <div className="bg-gray-700 rounded-lg p-3 text-sm text-gray-100">
                      {message.message}
                    </div>
                    
                    {/* Reactions */}
                    {JSON.parse(message.reactions) && Object.keys(JSON.parse(message.reactions)).length > 0 && (
                      <div className="flex items-center space-x-2 mt-2">
                        {Object.entries(JSON.parse(message.reactions)).map(([reaction, users]) => {
                          const emoji = reactionEmojis.find(e => e.name === reaction)?.emoji;
                          const userList = users as string[];
                          if (userList.length === 0) return null;
                          
                          return (
                            <button
                              key={reaction}
                              onClick={() => addReaction(message.id, reaction)}
                              className={`flex items-center space-x-1 px-2 py-1 rounded-full text-xs transition-colors ${
                                userList.includes(userId)
                                  ? 'bg-blue-500/20 text-blue-400 border border-blue-500/30'
                                  : 'bg-gray-600 text-gray-300 hover:bg-gray-500'
                              }`}
                            >
                              <span>{emoji}</span>
                              <span>{userList.length}</span>
                            </button>
                          );
                        })}
                      </div>
                    )}
                    
                    {/* Quick Reactions */}
                    <div className="opacity-0 group-hover:opacity-100 transition-opacity">
                      <div className="flex items-center space-x-1 mt-2">
                        {reactionEmojis.map(({ emoji, name }) => (
                          <button
                            key={name}
                            onClick={() => addReaction(message.id, name)}
                            className="w-6 h-6 text-xs hover:bg-gray-600 rounded flex items-center justify-center transition-colors"
                          >
                            {emoji}
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
          
          {/* Typing Indicator */}
          {typingUsers.length > 0 && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="flex items-center space-x-2 text-sm text-gray-400"
            >
              <div className="flex space-x-1">
                <div className="w-1 h-1 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                <div className="w-1 h-1 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                <div className="w-1 h-1 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
              </div>
              <span>
                {typingUsers.join(', ')} {typingUsers.length === 1 ? 'is' : 'are'} typing...
              </span>
            </motion.div>
          )}
        </div>
      </ScrollArea>

      {/* Input */}
      <div className="p-4 border-t border-gray-700">
        <div className="flex items-center space-x-2">
          <div className="relative flex-1">
            <Input
              ref={inputRef}
              value={newMessage}
              onChange={(e) => setNewMessage(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && sendMessage()}
              placeholder={`Message ${selectedParticipant ? participants.find(p => p.id === selectedParticipant)?.name : 'everyone'}...`}
              className="bg-gray-700 border-gray-600 text-white placeholder-gray-400 pr-20"
            />
            <div className="absolute right-2 top-1/2 transform -translate-y-1/2 flex items-center space-x-1">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setShowEmojiPicker(!showEmojiPicker)}
                className="h-6 w-6 p-0 text-gray-400 hover:text-white"
              >
                <Smile className="h-4 w-4" />
              </Button>
              <Button
                variant="ghost"
                size="sm"
                className="h-6 w-6 p-0 text-gray-400 hover:text-white"
              >
                <Paperclip className="h-4 w-4" />
              </Button>
            </div>
          </div>
          <Button
            onClick={sendMessage}
            disabled={!newMessage.trim()}
            className="bg-blue-500 hover:bg-blue-600 text-white"
            size="sm"
          >
            <Send className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </motion.div>
  );
}