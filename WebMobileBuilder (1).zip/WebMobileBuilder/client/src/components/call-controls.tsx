import { Button } from '@/components/ui/button';
import { Mic, MicOff, Video, VideoOff, Phone, Monitor, Settings } from 'lucide-react';

interface CallControlsProps {
  onToggleMicrophone: () => void;
  onToggleCamera: () => void;
  onEndCall: () => void;
  isMuted: boolean;
  isVideoEnabled: boolean;
}

export default function CallControls({
  onToggleMicrophone,
  onToggleCamera,
  onEndCall,
  isMuted,
  isVideoEnabled,
}: CallControlsProps) {
  
  const handleScreenShare = () => {
    // TODO: Implement screen sharing
    console.log('Screen share clicked');
  };

  const handleSettings = () => {
    // TODO: Implement settings modal
    console.log('Settings clicked');
  };

  return (
    <div className="absolute bottom-6 left-1/2 transform -translate-x-1/2">
      <div className="bg-black/80 backdrop-blur-sm rounded-full px-6 py-4 flex items-center space-x-4">
        
        {/* Microphone Toggle */}
        <Button
          variant="ghost"
          size="icon"
          className={`w-12 h-12 rounded-full transition-all duration-200 ${
            isMuted 
              ? 'bg-red-500 hover:bg-red-600' 
              : 'bg-gray-600 hover:bg-gray-500'
          }`}
          onClick={onToggleMicrophone}
        >
          {isMuted ? (
            <MicOff className="h-5 w-5 text-white" />
          ) : (
            <Mic className="h-5 w-5 text-white" />
          )}
        </Button>
        
        {/* Camera Toggle */}
        <Button
          variant="ghost"
          size="icon"
          className={`w-12 h-12 rounded-full transition-all duration-200 ${
            !isVideoEnabled 
              ? 'bg-red-500 hover:bg-red-600' 
              : 'bg-gray-600 hover:bg-gray-500'
          }`}
          onClick={onToggleCamera}
        >
          {isVideoEnabled ? (
            <Video className="h-5 w-5 text-white" />
          ) : (
            <VideoOff className="h-5 w-5 text-white" />
          )}
        </Button>
        
        {/* End Call */}
        <Button
          variant="ghost"
          size="icon"
          className="w-12 h-12 bg-red-500 hover:bg-red-600 rounded-full transition-all duration-200"
          onClick={onEndCall}
        >
          <Phone className="h-5 w-5 text-white rotate-135" />
        </Button>
        
        {/* Screen Share */}
        <Button
          variant="ghost"
          size="icon"
          className="w-12 h-12 bg-gray-600 hover:bg-gray-500 rounded-full transition-all duration-200"
          onClick={handleScreenShare}
        >
          <Monitor className="h-5 w-5 text-white" />
        </Button>
        
        {/* Settings */}
        <Button
          variant="ghost"
          size="icon"
          className="w-12 h-12 bg-gray-600 hover:bg-gray-500 rounded-full transition-all duration-200"
          onClick={handleSettings}
        >
          <Settings className="h-5 w-5 text-white" />
        </Button>
      </div>
    </div>
  );
}
