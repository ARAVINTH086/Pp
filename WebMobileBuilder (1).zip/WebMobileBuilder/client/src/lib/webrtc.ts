import { db } from './firebase';
import { collection, doc, onSnapshot, addDoc, updateDoc, deleteDoc } from 'firebase/firestore';

export interface SignalingMessage {
  type: 'offer' | 'answer' | 'ice-candidate';
  data: any;
  from: string;
  to: string;
}

export class WebRTCService {
  private peerConnection: RTCPeerConnection;
  private localStream: MediaStream | null = null;
  private roomId: string;
  private userId: string;
  private onRemoteStreamCallback?: (stream: MediaStream, userId: string) => void;
  private onParticipantLeftCallback?: (userId: string) => void;

  constructor(roomId: string, userId: string) {
    this.roomId = roomId;
    this.userId = userId;
    
    this.peerConnection = new RTCPeerConnection({
      iceServers: [
        { urls: 'stun:stun.l.google.com:19302' },
        { urls: 'stun:stun1.l.google.com:19302' },
      ],
    });

    this.setupPeerConnection();
    this.setupSignaling();
  }

  private setupPeerConnection() {
    this.peerConnection.onicecandidate = (event) => {
      if (event.candidate) {
        this.sendSignalingMessage({
          type: 'ice-candidate',
          data: event.candidate,
          from: this.userId,
          to: 'all',
        });
      }
    };

    this.peerConnection.ontrack = (event) => {
      const [remoteStream] = event.streams;
      // Extract user ID from track labels or use other method
      const remoteUserId = 'remote-user'; // This should be properly identified
      this.onRemoteStreamCallback?.(remoteStream, remoteUserId);
    };
  }

  private setupSignaling() {
    const signalingRef = collection(db, 'rooms', this.roomId, 'signaling');
    
    onSnapshot(signalingRef, (snapshot) => {
      snapshot.docChanges().forEach((change) => {
        if (change.type === 'added') {
          const message = change.doc.data() as SignalingMessage;
          if (message.from !== this.userId) {
            this.handleSignalingMessage(message);
          }
        }
      });
    });
  }

  private async sendSignalingMessage(message: SignalingMessage) {
    const signalingRef = collection(db, 'rooms', this.roomId, 'signaling');
    await addDoc(signalingRef, {
      ...message,
      timestamp: Date.now(),
    });
  }

  private async handleSignalingMessage(message: SignalingMessage) {
    switch (message.type) {
      case 'offer':
        await this.peerConnection.setRemoteDescription(message.data);
        const answer = await this.peerConnection.createAnswer();
        await this.peerConnection.setLocalDescription(answer);
        this.sendSignalingMessage({
          type: 'answer',
          data: answer,
          from: this.userId,
          to: message.from,
        });
        break;

      case 'answer':
        await this.peerConnection.setRemoteDescription(message.data);
        break;

      case 'ice-candidate':
        await this.peerConnection.addIceCandidate(message.data);
        break;
    }
  }

  async initializeLocalStream() {
    try {
      this.localStream = await navigator.mediaDevices.getUserMedia({
        video: true,
        audio: true,
      });

      this.localStream.getTracks().forEach((track) => {
        this.peerConnection.addTrack(track, this.localStream!);
      });

      return this.localStream;
    } catch (error) {
      console.error('Error accessing media devices:', error);
      throw new Error('Could not access camera and microphone');
    }
  }

  async createOffer() {
    const offer = await this.peerConnection.createOffer();
    await this.peerConnection.setLocalDescription(offer);
    
    this.sendSignalingMessage({
      type: 'offer',
      data: offer,
      from: this.userId,
      to: 'all',
    });
  }

  toggleAudio(enabled: boolean) {
    if (this.localStream) {
      this.localStream.getAudioTracks().forEach(track => {
        track.enabled = enabled;
      });
    }
  }

  toggleVideo(enabled: boolean) {
    if (this.localStream) {
      this.localStream.getVideoTracks().forEach(track => {
        track.enabled = enabled;
      });
    }
  }

  onRemoteStream(callback: (stream: MediaStream, userId: string) => void) {
    this.onRemoteStreamCallback = callback;
  }

  onParticipantLeft(callback: (userId: string) => void) {
    this.onParticipantLeftCallback = callback;
  }

  async disconnect() {
    if (this.localStream) {
      this.localStream.getTracks().forEach(track => track.stop());
    }
    
    this.peerConnection.close();
    
    // Clean up signaling data
    const signalingRef = collection(db, 'rooms', this.roomId, 'signaling');
    // Note: In a real implementation, you'd want to clean up user-specific signaling data
  }
}
