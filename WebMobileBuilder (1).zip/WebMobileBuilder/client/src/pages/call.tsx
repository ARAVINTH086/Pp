import { useEffect, useState } from 'react';
import { useLocation, useRoute } from 'wouter';
import { useWebRTC } from '@/hooks/use-webrtc';
import VideoTile from '@/components/video-tile';
import CallControls from '@/components/call-controls';
import LoadingOverlay from '@/components/loading-overlay';
import ErrorModal from '@/components/error-modal';
import { useToast } from '@/hooks/use-toast';
import { Users } from 'lucide-react';

export default function Call() {
  const [, params] = useRoute('/call/:roomId');
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  
  const [callDuration, setCallDuration] = useState(0);
  const [showParticipants, setShowParticipants] = useState(false);

  // Get URL parameters
  const urlParams = new URLSearchParams(window.location.search);
  const userId = urlParams.get('userId') || '';
  const userName = urlParams.get('userName') || 'Anonymous';
  const roomId = params?.roomId || '';

  const {
    localStream,
    participants,
    isConnected,
    isConnecting,
    error,
    isMuted,
    isVideoEnabled,
    toggleMicrophone,
    toggleCamera,
    endCall,
    retryConnection,
  } = useWebRTC(roomId, userId, userName);

  // Call duration timer
  useEffect(() => {
    if (!isConnected) return;

    const timer = setInterval(() => {
      setCallDuration(prev => prev + 1);
    }, 1000);

    return () => clearInterval(timer);
  }, [isConnected]);

  // Handle call end
  const handleEndCall = async () => {
    try {
      // Leave room on backend
      await fetch(`/api/rooms/${roomId}/leave`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId }),
      });
      
      endCall();
      toast({
        title: 'Call ended',
        description: 'You have left the call',
      });
      setLocation('/');
    } catch (error) {
      console.error('Error leaving room:', error);
      endCall();
      setLocation('/');
    }
  };

  const handleRetry = () => {
    retryConnection();
  };

  const handleBackToLobby = () => {
    endCall();
    setLocation('/');
  };

  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  // Redirect if no room ID or user ID
  if (!roomId || !userId) {
    setLocation('/');
    return null;
  }

  return (
    <div className="relative h-screen bg-gray-800">
      
      {/* Video Grid Container */}
      <div className="absolute inset-0 p-4">
        <div className="h-full grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          
          {/* Render participant video tiles */}
          {participants.map((participant) => (
            <VideoTile
              key={participant.id}
              participant={participant}
              isLocal={participant.id === userId}
            />
          ))}
          
          {/* Empty slots for additional participants */}
          {participants.length < 4 && (
            <div className="relative bg-gray-700/50 rounded-lg border-2 border-dashed border-gray-600 aspect-video flex items-center justify-center">
              <div className="text-center text-gray-400">
                <Users className="mx-auto mb-2 h-8 w-8" />
                <p className="text-sm">Waiting for participants...</p>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Call Information Header */}
      <div className="absolute top-4 left-4 bg-black/70 backdrop-blur-sm rounded-lg px-4 py-2">
        <div className="flex items-center space-x-3 text-white">
          <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse"></div>
          <span className="text-sm font-medium">Room: <span className="text-gray-300">{roomId}</span></span>
          <span className="text-xs text-gray-300">•</span>
          <span className="text-sm text-gray-300">{formatDuration(callDuration)}</span>
          <span className="text-xs text-gray-300">•</span>
          <span className="text-sm text-gray-300">{participants.length} participants</span>
        </div>
      </div>

      {/* Participants Panel Toggle */}
      <div className="absolute top-4 right-4">
        <button 
          className="bg-black/70 backdrop-blur-sm rounded-lg px-4 py-2 hover:bg-black/80 transition-colors flex items-center space-x-2 text-white"
          onClick={() => setShowParticipants(!showParticipants)}
        >
          <Users className="h-4 w-4" />
          <span className="text-sm">Participants</span>
        </button>
      </div>

      {/* Call Controls */}
      <CallControls
        onToggleMicrophone={toggleMicrophone}
        onToggleCamera={toggleCamera}
        onEndCall={handleEndCall}
        isMuted={isMuted}
        isVideoEnabled={isVideoEnabled}
      />

      {/* Loading Overlay */}
      {isConnecting && (
        <LoadingOverlay
          status="Setting up your video call"
          steps={[
            { text: 'Camera and microphone access', completed: !!localStream },
            { text: 'Connecting to room...', completed: false },
            { text: 'Establishing peer connection', completed: false },
          ]}
        />
      )}

      {/* Error Modal */}
      {error && (
        <ErrorModal
          title="Connection Failed"
          message={error}
          onRetry={handleRetry}
          onBackToLobby={handleBackToLobby}
        />
      )}
    </div>
  );
}
