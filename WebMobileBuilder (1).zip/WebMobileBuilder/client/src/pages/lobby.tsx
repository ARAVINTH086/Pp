import AdvancedLobby from '@/components/advanced-lobby';

export default function Lobby() {
  return <AdvancedLobby />;
}