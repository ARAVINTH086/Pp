import { useRoute } from 'wouter';
import { useQuery } from '@tanstack/react-query';
import AdvancedCall from '@/components/advanced-call';

export default function AdvancedCallPage() {
  const [, params] = useRoute('/advanced-call/:roomId');
  const roomId = params?.roomId;

  // Get current user ID from session or generate one
  const userId = sessionStorage.getItem('userId') || `user_${Date.now()}`;
  const userName = sessionStorage.getItem('userName') || 'Anonymous User';

  // Get room details
  const { data: room, isLoading } = useQuery({
    queryKey: [`/api/rooms/${roomId}`],
    enabled: !!roomId
  });

  if (isLoading) {
    return (
      <div className="h-screen bg-gray-900 flex items-center justify-center">
        <div className="text-white">Joining call...</div>
      </div>
    );
  }

  if (!room || !roomId) {
    return (
      <div className="h-screen bg-gray-900 flex items-center justify-center">
        <div className="text-center text-white">
          <h1 className="text-2xl font-bold mb-4">Room not found</h1>
          <button onClick={() => window.location.href = '/'}>
            Return to Lobby
          </button>
        </div>
      </div>
    );
  }

  return (
    <AdvancedCall
      roomId={roomId}
      userId={userId}
      userName={userName}
    />
  );
}