import {
  users,
  rooms,
  participants,
  callHistory,
  type User,
  type InsertUser,
  type Room,
  type InsertRoom,
  type Participant,
  type InsertParticipant,
  type CallHistory,
  type InsertCallHistory,
} from "@shared/schema";

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  createRoom(room: InsertRoom): Promise<Room>;
  getRoom(id: string): Promise<Room | undefined>;
  getRoomsByUser(userId: string): Promise<Room[]>;
  updateRoomStatus(id: string, isActive: boolean): Promise<void>;
  
  addParticipant(participant: InsertParticipant): Promise<Participant>;
  getParticipantsByRoom(roomId: string): Promise<Participant[]>;
  removeParticipant(roomId: string, userId: string): Promise<void>;
  
  getCallHistory(userId: string): Promise<CallHistory[]>;
  createCallHistory(callHistory: InsertCallHistory): Promise<CallHistory>;
  updateCallHistory(id: number, duration: number, endedAt: Date): Promise<void>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private rooms: Map<string, Room>;
  private participants: Map<string, Participant[]>;
  private callHistoryRecords: Map<number, CallHistory>;
  private currentUserId: number;
  private currentHistoryId: number;

  constructor() {
    this.users = new Map();
    this.rooms = new Map();
    this.participants = new Map();
    this.callHistoryRecords = new Map();
    this.currentUserId = 1;
    this.currentHistoryId = 1;
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async createRoom(insertRoom: InsertRoom): Promise<Room> {
    const id = `room_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    const room: Room = {
      ...insertRoom,
      id,
      createdAt: new Date(),
      isActive: true,
    };
    this.rooms.set(id, room);
    this.participants.set(id, []);
    return room;
  }

  async getRoom(id: string): Promise<Room | undefined> {
    return this.rooms.get(id);
  }

  async getRoomsByUser(userId: string): Promise<Room[]> {
    return Array.from(this.rooms.values()).filter(
      room => room.createdBy === userId || 
      this.participants.get(room.id)?.some(p => p.userId === userId)
    );
  }

  async updateRoomStatus(id: string, isActive: boolean): Promise<void> {
    const room = this.rooms.get(id);
    if (room) {
      this.rooms.set(id, { ...room, isActive });
    }
  }

  async addParticipant(insertParticipant: InsertParticipant): Promise<Participant> {
    const participant: Participant = {
      ...insertParticipant,
      id: Date.now(),
      joinedAt: new Date(),
      leftAt: null,
      isActive: true,
    };
    
    const roomParticipants = this.participants.get(insertParticipant.roomId) || [];
    roomParticipants.push(participant);
    this.participants.set(insertParticipant.roomId, roomParticipants);
    
    return participant;
  }

  async getParticipantsByRoom(roomId: string): Promise<Participant[]> {
    return this.participants.get(roomId)?.filter(p => p.isActive) || [];
  }

  async removeParticipant(roomId: string, userId: string): Promise<void> {
    const roomParticipants = this.participants.get(roomId) || [];
    const updated = roomParticipants.map(p => 
      p.userId === userId ? { ...p, isActive: false, leftAt: new Date() } : p
    );
    this.participants.set(roomId, updated);
  }

  async getCallHistory(userId: string): Promise<CallHistory[]> {
    const userRooms = await this.getRoomsByUser(userId);
    const roomIds = new Set(userRooms.map(r => r.id));
    
    return Array.from(this.callHistoryRecords.values())
      .filter(call => roomIds.has(call.roomId))
      .sort((a, b) => b.startedAt.getTime() - a.startedAt.getTime());
  }

  async createCallHistory(insertCallHistory: InsertCallHistory): Promise<CallHistory> {
    const id = this.currentHistoryId++;
    const callHistory: CallHistory = { 
      ...insertCallHistory, 
      id,
      duration: insertCallHistory.duration ?? null,
      endedAt: insertCallHistory.endedAt ?? null
    };
    this.callHistoryRecords.set(id, callHistory);
    return callHistory;
  }

  async updateCallHistory(id: number, duration: number, endedAt: Date): Promise<void> {
    const record = this.callHistoryRecords.get(id);
    if (record) {
      this.callHistoryRecords.set(id, { ...record, duration, endedAt });
    }
  }
}

export const storage = new MemStorage();
