import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertRoomSchema, insertParticipantSchema, insertCallHistorySchema } from "@shared/schema";
import { z } from "zod";

const joinRoomSchema = z.object({
  roomId: z.string().min(1),
  userName: z.string().min(1),
  userId: z.string().min(1),
});

const createRoomSchema = insertRoomSchema.extend({
  userName: z.string().min(1),
  userId: z.string().min(1),
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Create a new room
  app.post("/api/rooms", async (req, res) => {
    try {
      const { userName, userId, ...roomData } = createRoomSchema.parse(req.body);
      
      const room = await storage.createRoom({
        ...roomData,
        createdBy: userId,
      });

      // Add creator as first participant
      await storage.addParticipant({
        roomId: room.id,
        userId,
        name: userName,
      });

      // Create call history record
      await storage.createCallHistory({
        roomId: room.id,
        roomName: room.name,
        participantCount: 1,
        startedAt: new Date(),
        duration: null,
        endedAt: null,
      });

      res.json(room);
    } catch (error) {
      console.error("Error creating room:", error);
      res.status(400).json({ message: "Failed to create room" });
    }
  });

  // Join an existing room
  app.post("/api/rooms/:roomId/join", async (req, res) => {
    try {
      const { roomId } = req.params;
      const { userName, userId } = joinRoomSchema.parse({ roomId, ...req.body });

      const room = await storage.getRoom(roomId);
      if (!room) {
        return res.status(404).json({ message: "Room not found" });
      }

      if (!room.isActive) {
        return res.status(400).json({ message: "Room is not active" });
      }

      // Check if user is already in the room
      const existingParticipants = await storage.getParticipantsByRoom(roomId);
      const isAlreadyJoined = existingParticipants.some(p => p.userId === userId);

      if (!isAlreadyJoined) {
        await storage.addParticipant({
          roomId,
          userId,
          name: userName,
        });
      }

      const participants = await storage.getParticipantsByRoom(roomId);
      
      res.json({
        room,
        participants,
      });
    } catch (error) {
      console.error("Error joining room:", error);
      res.status(400).json({ message: "Failed to join room" });
    }
  });

  // Leave a room
  app.post("/api/rooms/:roomId/leave", async (req, res) => {
    try {
      const { roomId } = req.params;
      const { userId } = req.body;

      await storage.removeParticipant(roomId, userId);
      
      const participants = await storage.getParticipantsByRoom(roomId);
      
      // If no participants left, mark room as inactive
      if (participants.length === 0) {
        await storage.updateRoomStatus(roomId, false);
      }

      res.json({ success: true });
    } catch (error) {
      console.error("Error leaving room:", error);
      res.status(400).json({ message: "Failed to leave room" });
    }
  });

  // Get room details
  app.get("/api/rooms/:roomId", async (req, res) => {
    try {
      const { roomId } = req.params;
      const room = await storage.getRoom(roomId);
      
      if (!room) {
        return res.status(404).json({ message: "Room not found" });
      }

      const participants = await storage.getParticipantsByRoom(roomId);
      
      res.json({
        room,
        participants,
      });
    } catch (error) {
      console.error("Error fetching room:", error);
      res.status(500).json({ message: "Failed to fetch room details" });
    }
  });

  // Get call history for a user
  app.get("/api/call-history/:userId", async (req, res) => {
    try {
      const { userId } = req.params;
      const history = await storage.getCallHistory(userId);
      res.json(history);
    } catch (error) {
      console.error("Error fetching call history:", error);
      res.status(500).json({ message: "Failed to fetch call history" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
