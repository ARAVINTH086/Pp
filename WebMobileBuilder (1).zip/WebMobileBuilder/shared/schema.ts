import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const rooms = pgTable("rooms", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  createdBy: text("created_by").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  isActive: boolean("is_active").default(true).notNull(),
  roomType: text("room_type").default("video").notNull(), // video, audio, screen-share
  maxParticipants: integer("max_participants").default(10).notNull(),
  isRecording: boolean("is_recording").default(false).notNull(),
  recordingUrl: text("recording_url"),
  backgroundBlur: boolean("background_blur").default(false).notNull(),
  isLocked: boolean("is_locked").default(false).notNull(),
  password: text("password"),
  waitingRoom: boolean("waiting_room").default(false).notNull(),
  chatEnabled: boolean("chat_enabled").default(true).notNull(),
  screenShareEnabled: boolean("screen_share_enabled").default(true).notNull(),
  whiteboardEnabled: boolean("whiteboard_enabled").default(true).notNull(),
});

export const participants = pgTable("participants", {
  id: serial("id").primaryKey(),
  roomId: text("room_id").notNull(),
  userId: text("user_id").notNull(),
  name: text("name").notNull(),
  joinedAt: timestamp("joined_at").defaultNow().notNull(),
  leftAt: timestamp("left_at"),
  isActive: boolean("is_active").default(true).notNull(),
  isMuted: boolean("is_muted").default(false).notNull(),
  isVideoEnabled: boolean("is_video_enabled").default(true).notNull(),
  isScreenSharing: boolean("is_screen_sharing").default(false).notNull(),
  isHandRaised: boolean("is_hand_raised").default(false).notNull(),
  role: text("role").default("participant").notNull(), // host, moderator, participant
  avatar: text("avatar"),
  connectionQuality: text("connection_quality").default("good").notNull(), // excellent, good, fair, poor
  inWaitingRoom: boolean("in_waiting_room").default(false).notNull(),
});

export const callHistory = pgTable("call_history", {
  id: serial("id").primaryKey(),
  roomId: text("room_id").notNull(),
  roomName: text("room_name").notNull(),
  participantCount: integer("participant_count").notNull(),
  duration: integer("duration"), // in seconds
  startedAt: timestamp("started_at").notNull(),
  endedAt: timestamp("ended_at"),
  recordingUrl: text("recording_url"),
  peakParticipants: integer("peak_participants").default(1).notNull(),
  meetingType: text("meeting_type").default("video").notNull(),
  avgConnectionQuality: text("avg_connection_quality").default("good").notNull(),
});

export const chatMessages = pgTable("chat_messages", {
  id: serial("id").primaryKey(),
  roomId: text("room_id").notNull(),
  userId: text("user_id").notNull(),
  userName: text("user_name").notNull(),
  message: text("message").notNull(),
  messageType: text("message_type").default("text").notNull(), // text, file, emoji, poll
  timestamp: timestamp("timestamp").defaultNow().notNull(),
  isPrivate: boolean("is_private").default(false).notNull(),
  recipientId: text("recipient_id"),
  fileUrl: text("file_url"),
  fileName: text("file_name"),
  reactions: text("reactions").default("{}").notNull(), // JSON string of reactions
});

export const breakoutRooms = pgTable("breakout_rooms", {
  id: serial("id").primaryKey(),
  mainRoomId: text("main_room_id").notNull(),
  name: text("name").notNull(),
  participantIds: text("participant_ids").array(), // Array of participant IDs
  createdAt: timestamp("created_at").defaultNow().notNull(),
  isActive: boolean("is_active").default(true).notNull(),
  duration: integer("duration"), // in minutes
  autoClose: boolean("auto_close").default(false).notNull(),
});

export const whiteboardData = pgTable("whiteboard_data", {
  id: serial("id").primaryKey(),
  roomId: text("room_id").notNull(),
  data: text("data").notNull(), // JSON string of whiteboard data
  lastModified: timestamp("last_modified").defaultNow().notNull(),
  modifiedBy: text("modified_by").notNull(),
});

export const aiTranscripts = pgTable("ai_transcripts", {
  id: serial("id").primaryKey(),
  roomId: text("room_id").notNull(),
  speakerId: text("speaker_id").notNull(),
  speakerName: text("speaker_name").notNull(),
  transcript: text("transcript").notNull(),
  timestamp: timestamp("timestamp").defaultNow().notNull(),
  confidence: integer("confidence").default(95).notNull(), // 0-100
  language: text("language").default("en").notNull(),
});

export const roomAnalytics = pgTable("room_analytics", {
  id: serial("id").primaryKey(),
  roomId: text("room_id").notNull(),
  speakingTime: text("speaking_time").notNull(), // JSON object with user speaking times
  participationMetrics: text("participation_metrics").notNull(), // JSON analytics data
  qualityMetrics: text("quality_metrics").notNull(), // Connection quality over time
  engagementScore: integer("engagement_score").default(0).notNull(),
  generatedAt: timestamp("generated_at").defaultNow().notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertRoomSchema = createInsertSchema(rooms).omit({
  id: true,
  createdAt: true,
  isActive: true,
});

export const insertParticipantSchema = createInsertSchema(participants).omit({
  id: true,
  joinedAt: true,
  leftAt: true,
  isActive: true,
});

export const insertCallHistorySchema = createInsertSchema(callHistory).omit({
  id: true,
});

export const insertChatMessageSchema = createInsertSchema(chatMessages).omit({
  id: true,
  timestamp: true,
});

export const insertBreakoutRoomSchema = createInsertSchema(breakoutRooms).omit({
  id: true,
  createdAt: true,
  isActive: true,
});

export const insertWhiteboardDataSchema = createInsertSchema(whiteboardData).omit({
  id: true,
  lastModified: true,
});

export const insertAiTranscriptSchema = createInsertSchema(aiTranscripts).omit({
  id: true,
  timestamp: true,
});

export const insertRoomAnalyticsSchema = createInsertSchema(roomAnalytics).omit({
  id: true,
  generatedAt: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type Room = typeof rooms.$inferSelect;
export type InsertRoom = z.infer<typeof insertRoomSchema>;
export type Participant = typeof participants.$inferSelect;
export type InsertParticipant = z.infer<typeof insertParticipantSchema>;
export type CallHistory = typeof callHistory.$inferSelect;
export type InsertCallHistory = z.infer<typeof insertCallHistorySchema>;
export type ChatMessage = typeof chatMessages.$inferSelect;
export type InsertChatMessage = z.infer<typeof insertChatMessageSchema>;
export type BreakoutRoom = typeof breakoutRooms.$inferSelect;
export type InsertBreakoutRoom = z.infer<typeof insertBreakoutRoomSchema>;
export type WhiteboardData = typeof whiteboardData.$inferSelect;
export type InsertWhiteboardData = z.infer<typeof insertWhiteboardDataSchema>;
export type AiTranscript = typeof aiTranscripts.$inferSelect;
export type InsertAiTranscript = z.infer<typeof insertAiTranscriptSchema>;
export type RoomAnalytics = typeof roomAnalytics.$inferSelect;
export type InsertRoomAnalytics = z.infer<typeof insertRoomAnalyticsSchema>;
